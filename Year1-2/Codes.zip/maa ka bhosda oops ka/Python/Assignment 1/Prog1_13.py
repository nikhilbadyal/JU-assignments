if __name__ == "__main__":
    
    
    dic = {x: x.swapcase() for x in "Aman Sharma"} #Insert your name here
    print(dic)
