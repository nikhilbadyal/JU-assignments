if __name__ == "__main__":

    for index,element in enumerate(range(97,123),1):
        print(index,chr(element))
