
class Prog1_2
{
	public static void main(String args[])
	{
		int n=0;
		System.out.println("The input strings are :");
		for(n=0;n<args.length;n++)
		{
			System.out.println(args[n]);
		}
		System.out.println("Number of strings= "+n);
	}
}