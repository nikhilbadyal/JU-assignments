package test;

public class Main {
    public static void main(String[] args) {
        DataList dl = new DataList();
        dl.addDataList(1,2,3,4,5);
    }
}
