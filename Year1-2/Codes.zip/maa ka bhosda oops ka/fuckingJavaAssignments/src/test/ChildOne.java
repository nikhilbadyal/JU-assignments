package test;

public class ChildOne extends DataList {

    public void accessMethod(){

    }
}
