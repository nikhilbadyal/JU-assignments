package test;

import java.util.ArrayList;

public class DataList {
    private ArrayList<Data> dataList = new ArrayList<>();

    static int count = 0;
    public void addDataList(double att1,double att2,double att3,double att4,double att5) {
        Data data = new Data(att1,att2,att3,att4,att5);
        dataList.add(data);
        count++;
    }

    public Double StandardDeviationAttributeOne(){
        double mean = 0, x = 0;
        for(int i=0;i<dataList.size();i++){
            mean = mean + dataList.get(i).getAtt1();
        }
        for(int i=0;i<dataList.size();i++){
            x = (dataList.get(i).getAtt1() - mean) + x;
            x = (x*x);
        }
        x = x/dataList.size();
        x=Math.sqrt(x);
        return x;
    }

    public Double StandardDeviationAttributeTwo(){
        double mean = 0, x = 0;
        for(int i=0;i<dataList.size();i++){
            mean = mean + dataList.get(i).getAtt2();
        }
        for(int i=0;i<dataList.size();i++){
            x = (dataList.get(i).getAtt1() - mean) + x;
            x = (x*x);
        }
        x = x/dataList.size();
        x=Math.sqrt(x);
        return x;
    }

    public Double StandardDeviationAttributeThree(){
        double mean = 0, x = 0;
        for(int i=0;i<dataList.size();i++){
            mean = mean + dataList.get(i).getAtt3();
        }
        for(int i=0;i<dataList.size();i++){
            x = (dataList.get(i).getAtt1() - mean) + x;
            x = (x*x);
        }
        x = x/dataList.size();
        x=Math.sqrt(x);
        return x;
    }

    public Double StandardDeviationAttributeFour(){
        double mean = 0, x = 0;
        for(int i=0;i<dataList.size();i++){
            mean = mean + dataList.get(i).getAtt4();
        }
        for(int i=0;i<dataList.size();i++){
            x = (dataList.get(i).getAtt1() - mean) + x;
            x = (x*x);
        }
        x = x/dataList.size();
        x=Math.sqrt(x);
        return x;
    }

    public Double StandardDeviationAttributeFive(){
        double mean = 0, x = 0;
        for(int i=0;i<dataList.size();i++){
            mean = mean + dataList.get(i).getAtt5();
        }
        for(int i=0;i<dataList.size();i++){
            x = (dataList.get(i).getAtt1() - mean) + x;
            x = (x*x);
        }
        x = x/dataList.size();
        x=Math.sqrt(x);
        return x;
    }
}
