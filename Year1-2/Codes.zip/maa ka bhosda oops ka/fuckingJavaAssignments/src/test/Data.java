package test;
//write a java program that takes a data set containing hundred instances and different attributes for
// each of the instance the attributes values are single in nature .Design a method which will calculate
// the standard deviation for the instances with respect to each of the features.
//Two classes will be declared  as the children to access the data set.
//one class will get access of the method standard deviation another class will calculate the average
// of the
// attribute value.Show which oof the child classes the instances are distributed with respect to standard
//deviation and average.

public class Data {
    private double att1;
    private double att2;
    private double att3;
    private double att4;
    private double att5;

    public Data(double att1, double att2, double att3, double att4, double att5) {
        this.att1 = att1;
        this.att2 = att2;
        this.att3 = att3;
        this.att4 = att4;
        this.att5 = att5;
    }

    public double getAtt1() {
        return att1;
    }

    public double getAtt2() {
        return att2;
    }

    public double getAtt3() {
        return att3;
    }

    public double getAtt4() {
        return att4;
    }

    public double getAtt5() {
        return att5;
    }
}