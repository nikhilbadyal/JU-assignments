//package test;
////
////public class ChildTwo extends DataList{
////
////    public double averageValue(){
////        double average = 0;
////        for(int i=0;i<)
////    }
////}
