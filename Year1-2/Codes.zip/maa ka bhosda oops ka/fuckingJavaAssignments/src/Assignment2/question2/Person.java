package Assignment2.question2;

public abstract class Person {
    private String name;
    private String phone;
    private String email;
    private Address a;

    private class Address{
        private String premises;
        private String state;
        private String city;
        private String pin;

        public Address(String premises, String state, String city, String pin) {
            this.premises = premises;
            this.state = state;
            this.city = city;
            this.pin = pin;
        }

        public void setPremises(String premises) {
            this.premises = premises;
        }

        public void setState(String state) {
            this.state = state;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public void setPin(String pin) {
            this.pin = pin;
        }

        public void showAddress() {
            System.out.println(premises+", "+state+", "+city+", "+pin);
        }
    }

    public Person(String name, String phone, String email, String premises,String state,String city,String pin) {
        this.a = new Address(premises,state,city,pin);
        this.name = name;
        this.phone = phone;
        this.email = email;
    }


    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public void showA() {
         a.showAddress();
    }

    public void updateAddress(String newData,int n) {
        switch(n){
            case 0: a.setPremises(newData);
                   break;

            case 1: a.setState(newData);
                    break;

            case 2: a.setCity(newData);
                    break;

            case 3: a.setPin(newData);
                    break;

            default: System.out.println("illegal choice");
        }
    }
}
