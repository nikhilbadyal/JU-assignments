package Assignment2.question2;

public class Main {

    public static void main(String[] args){
        Student s = new Student("aman","9682651543","amanshama1823758@gmail,com","21/1 baghajatin","west bengal","kolkata","700092","001810501068","computer science");
        s.showDetails();
        Faculty f= new Faculty("raman","7006210149","ramansharma222222@gmail.com","110/5 nanak nagar","Jammu and kashmir","jammu","180004","210105","cse","oops");
        f.showDetails();

        s.updateAddress("16/1/A baghajatin",0);
        s.showDetails();
    }
}
