package Assignment2.question2;

public class Student extends Person{
    private String roll;
    private String studyCourse;


    public Student(String name, String phone, String email, String premises, String state, String city, String pin, String roll, String studyCourse) {
        super(name, phone, email, premises, state, city, pin);
        this.roll = roll;
        this.studyCourse = studyCourse;
    }


    public void showDetails(){
        System.out.println("Student detail :" +'\n'+
                           "Name : " + getName() +'\n'+
                           "Roll : " +getRoll() +'\n'+
                           "Course : " + getStudyCourse()+'\n'+
                           "email : " + getEmail()+'\n' +
                           "Address : ");
                           showA();
    }
    public String getRoll() {
        return roll;
    }

    public String getStudyCourse() {
        return studyCourse;
    }
}
