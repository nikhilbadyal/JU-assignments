package Assignment2.question2;

public class Faculty extends Person{
    private String emloyeeId;
    private String depart;
    private String specialization;



    public Faculty(String name, String phone, String email, String premises, String state, String city, String pin, String emloyeeId, String depart, String specialization) {
        super(name, phone, email, premises, state, city, pin);
        this.emloyeeId = emloyeeId;
        this.depart = depart;
        this.specialization = specialization;
    }

    public void showDetails() {
        System.out.println("Faculty detail :" + '\n' +
                "Name : " + getName() +'\n'+
                "email : " + getEmail()+'\n' +
                "EmpId : " + getEmloyeeId() + '\n' +
                "Department : " + getDepart() + '\n' +
                "Specialization :  " +  getSpecialization()+ '\n' +
                "Address : " );
        showA();
    }

    public String getEmloyeeId() {
        return emloyeeId;
    }

    public String getDepart() {
        return depart;
    }

    public String getSpecialization() {
        return specialization;
    }
}
