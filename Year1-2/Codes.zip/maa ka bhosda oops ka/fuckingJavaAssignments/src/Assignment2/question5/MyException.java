package Assignment2.question5;

public class MyException extends Exception {
    int score;

    public MyException(int score) {
        this.score = score;
    }
    public String toString(){
        return "My Exception, Score = " + score + " Which is non negative and cannot exceed more than 100";
    }
}
