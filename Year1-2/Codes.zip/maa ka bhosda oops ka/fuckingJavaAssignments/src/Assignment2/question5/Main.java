package Assignment2.question5;

public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        s.setName("aman");
        s.setRoll(68);
        try{
            s.setScore(10000);
        }
        catch(MyException e){
            System.out.println(e);
        }
        System.out.println(s.getRoll());
        System.out.println(s.getName());
        System.out.println(s.getScore());
    }
}
