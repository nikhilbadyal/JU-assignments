package Assignment2.question5;

public interface IStudent {
    void setRoll(int roll);
    void setName(String name);
    void setScore(int score) throws MyException;
}
