package Assignment2.question5;

public class Student implements IStudent {
    private int roll;
    private String name;
    private int score;



    public void setRoll(int roll) {
        this.roll = roll;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setScore(int score) throws MyException {
        if (score < 0 || score > 100)
            throw new MyException(score);
        else{
            this.score = score;
        }
    }

    public int getRoll() {
        return roll;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }
}
