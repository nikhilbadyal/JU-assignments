package Assignment2.Library;

import Assignment2.BookList.BookList;
import Assignment2.MemberList.MemberList;;
import Assignment2.TransactionList.TransactionList;
import Assignment2.question4.ILibrary;


public class Library implements ILibrary {
    private MemberList memberList;
    private BookList bookList;
    private TransactionList transactionList;

    public Library() {
        memberList = new MemberList();
        bookList = new BookList();
        transactionList = new TransactionList();
    }

   /* public void libraryFunctions(){
        System.out.println("1. Issue book : " + '\n' +
                           "2. return book : ");
        Scanner scanner = new Scanner(System.in);

        while(1){
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch(choice){

                case 1 : issueBook();
            }
        }
    }*/

   public boolean issueBook(int memberId,int bookId){
       int bookNumber,memberNumber;
       memberNumber = memberList.checkMember(memberId);
       bookNumber = bookList.checkUnique(bookId);

       if(memberNumber == -1 || bookNumber == -1){  // check if the member id and book id is valid or not
           return false;
       }
       else{
          if(memberList.issueBookRequest(memberNumber) && bookList.issueBook(bookNumber)){    //checking if member have limited books and book is available or not
              transactionList.addTransaction(memberId,bookId);
              return true;
          }
          return false;
       }
   }

   public boolean returnBook(int memberId,int bookId){
       return transactionList.updateTransation(memberId, bookId);
   }

   public void addMember(int id,String name, String dob){
       memberList.addMember(id,name,dob);
   }

   public void addBook(int id,String title,int noOfBooks){ bookList.addBook(id, title, noOfBooks);
   }
   public boolean searchBook(int bookId){
       if(bookList.checkUnique(bookId) == -1)
           return false;
       else {
           bookList.showBook(bookId);
           return false;
       }
   }

    public boolean searchMember(int memberId){
        if(memberList.checkMember(memberId) == -1)
            return false;
        else {
            memberList.showMembers(memberId);
            return false;
        }
    }

   public boolean addCopyOfBook(int bookId,int noOfBooks){
      return bookList.addCopyPurchased(bookId,noOfBooks);
   }

   public boolean showBook(int bookId){
        return bookList.showBook(bookId);
    }

    public void showBook(){
        bookList.showBook();
    }

    public boolean showMember(int memberId){
        return memberList.showMembers(memberId);
    }

    public void showMember(){
        memberList.showMembers();
    }

    public void showTransactionList(){
       transactionList.showTransactions();
    }
}
