package Assignment2.Library;

public class Main {
    public static void main(String[] args){
        Library l = new Library();
        l.addBook(43,"aman",4);
        l.addBook(54,"raman",3);
        l.addMember(98,"aman","2/2/2000");
        l.showBook();
        l.showMember();
        l.showMember(43);
    }
}
