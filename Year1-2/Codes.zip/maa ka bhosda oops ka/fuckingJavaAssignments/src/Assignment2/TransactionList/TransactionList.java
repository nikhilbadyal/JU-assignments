package Assignment2.TransactionList;

public class TransactionList {
    public class TrList {
        private Transaction t;
        private char tag;

        public TrList(int memberId, int bookId) {
            this.t = new Transaction(memberId, bookId);
            tag = 'i';
        }

        public int getMemberId() {
            return t.getMemberId();
        }

        public void updateMemberId(int memberId) {
            t.setMemberId(memberId);
        }

        public int getBookId() {
            return t.getBookId();
        }

        public void updateBookId(int bookId) {
            t.setMemberId(bookId);
        }

        public char getTag() {
            return tag;
        }

        public void updateTag(char tag) {
            this.tag = tag;
        }
    }

    private TrList[] transactions;

    public static int count = 0;

    public TransactionList() {
        this.transactions = new TrList[100];
    }

    public void addTransaction(int memberId, int bookId) {
        transactions[count++] = new TrList(memberId, bookId);
    }

    public boolean modifyEntry(int id, char tag, int newId) {
        if (tag == 'b')
            return modifyMemberId(id, newId);
        else
            return modifyBookId(id, newId);
    }

    public boolean modifyMemberId(int id, int newId) {
        for (int i = 0; i < transactions.length; i++) {
            if (transactions[i].getMemberId() == id) {
                transactions[i].updateMemberId(newId);
                return true;
            }
        }
        return false;
    }

    public boolean modifyBookId(int id, int newId) {
        for (int i = 0; i < count; i++) {
            if (transactions[i].getBookId() == id) {
                transactions[i].updateBookId(newId);
                return true;
            }
        }
        return false;
    }

    public int checkTransation(int memberId, int bookId) {
        for (int i = 0; i < count; i++) {
            if (transactions[i].getMemberId() == memberId && transactions[i].getBookId() == bookId && transactions[i].getTag() == 'i')
                return i;
        }
        return -1;
    }

    public boolean updateTransation(int memberId, int bookId) {
        int check = checkTransation(memberId, bookId);
        if (check != -1) {
            transactions[check].updateTag('r');
            return true;
        }
        else
            return false;
    }

    public void showTransactions(){
        for(int i=0;i<count;i++){
            System.out.println(transactions[i].getBookId() + "\n" +
                                transactions[i].getMemberId() + "\n" +
                                transactions[i].getTag() + "\n");
        }
    }
}
