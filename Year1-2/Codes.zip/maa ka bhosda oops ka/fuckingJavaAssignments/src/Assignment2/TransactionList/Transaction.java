package Assignment2.TransactionList;

public class Transaction {
    private int memberId;
    private int bookId;

    public Transaction(int memberId, int bookId) {
        this.memberId = memberId;
        this.bookId = bookId;
    }

    public int getMemberId() {
        return memberId;
    }

    public int getBookId() { return bookId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }
}
