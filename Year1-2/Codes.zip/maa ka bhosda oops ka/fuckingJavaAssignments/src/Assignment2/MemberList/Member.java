package Assignment2.MemberList;

public class Member {
    private int id;
    private String name;
    private String dob;
    private int booksIssued;

    private static final int maxBook = 5;
    public Member(int id, String name, String dob) {
        this.id = id;
        this.name = name;
        this.dob = dob;
        this.booksIssued = 0;
    }


    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDob() {
        return dob;
    }

    public int getBooksIssued() {
        return booksIssued;
    }

    public boolean updateBookIssued(){
        if(booksIssued < maxBook){
            booksIssued += 1;
            return true;
        }
        else
            return false;
    }
}
