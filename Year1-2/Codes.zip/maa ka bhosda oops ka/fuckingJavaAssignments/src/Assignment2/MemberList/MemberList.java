package Assignment2.MemberList;

public class MemberList {
    private Member[] members;

    public static int count = 0;

    public MemberList() {
        this.members = new Member[100];
    }

    public void addMember(int id, String name, String dob){
        int check = checkMember(id);
        try{
            if(check == -1){
                this.members[count] = new Member(id,name,dob);
                count++;
            }
        }
        catch(ArrayIndexOutOfBoundsException a){
            System.out.println( "Array out of  index at  : " + a);
        }
    }

    public void showMembers(){
        for(int i=0; i<count;i++)
            System.out.println("Id : " + members[i].getId() + '\n' +
                    "Name : " + members[i].getName() + '\n' +
                    "Dob : " + members[i].getDob() + '\n' +
                    "Total number of books issued : " + members[i].getBooksIssued());
    }
    public boolean showMembers(int id){
        int check = checkMember(id);
        if(check == -1) return false;
        else{
            System.out.println("Id : " + members[check].getId() + '\n' +
                    "Name : " + members[check].getName() + '\n' +
                    "Dob : " + members[check].getDob() +
                    "Total number of books issued : " + members[check].getBooksIssued());
            return true;
        }
    }

    public int checkMember(int id){
        for(int i=0;i<count;i++)
            if (members[i].getId() == id)
                return i;
        return -1;
    }

    public boolean issueBookRequest(int memberNumber){
        return members[memberNumber].updateBookIssued();
    }

    /*public static void main(String[] args) {
        MemberList m = new MemberList();
        m.addMember(98,"aman","2/2/2000");
        m.showMembers();
    }*/
}
