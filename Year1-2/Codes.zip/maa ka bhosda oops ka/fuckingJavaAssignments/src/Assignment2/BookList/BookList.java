package Assignment2.BookList;

public class BookList {

   public class BkList{
       private Book b;
       private int bookAvailable;

       public int getBookId(){
           return b.getId();
       }
       public void setDetails(int id,String title,int noBooks){
           b = new Book(id,title,noBooks);
           b.setBookPurchased(noBooks);
           b.setId(id);
           b.setTitle(title);
           updateAvailability(noBooks);
       }
       public void updateAvailability(int noBooks){
           System.out.println(bookAvailable);
           this.bookAvailable += noBooks;
           System.out.println(bookAvailable);
       }
       public void show(){
           System.out.println("Id : " + b.getId() + '\n' +
                              "Title : " + b.getTitle() + '\n' +
                               "Total books purchased : " + b.getBookPurchased() + '\n' +
                               "Total books available : " + getBookAvailable());
       }

       public int getBookAvailable(){
           return bookAvailable;
       }
   }

    private BkList[] books;

    public static int count = 0;
    public BookList() {
        this.books = new BkList[100];
    }

    public void addBook(int id, String title, int noBook) {
        int check = checkUnique(id);
        try{
            if(check == -1) {
                this.books[count] = new BkList();
                this.books[count].setDetails(id, title, noBook);
                count++;
            }
            else {
                books[check].updateAvailability(noBook);
            }
        }
        catch(ArrayIndexOutOfBoundsException a){
            System.out.println( "Array out of  index at  : " + a);
        }
    }

    public int checkUnique(int id){
        for(int i=0;i<count;i++)
            if (books[i].getBookId() == id)
                return i;
        return -1;
    }

    public boolean addCopyPurchased(int bookId,int noOfBooks){
        int check = checkUnique(bookId);
        if(check == -1){
            return false;
        }
        else {
            books[check].updateAvailability(noOfBooks);
            return true;
        }
    }

    public boolean showBook(int bookId) {
        int check = checkUnique(bookId);
        if (check == -1) {
            return false;
        } else
            books[check].show();
        return false;
    }

    public void showBook(){
        for(int i=0;i<count;i++){
            books[i].show();
        }
    }

    public boolean issueBook(int bookNumber){
        if(books[bookNumber].getBookAvailable() > 0){
            books[bookNumber].updateAvailability(-1);
            return true;
        }
        return false;
    }
}
