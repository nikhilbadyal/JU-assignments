package Assignment2.BookList;

public class Book {
    private int id;
    private String title;
    private int bookPurchased;

    public Book(int id, String title,int bookPurchased) {
        this.id = id;
        this.title = title;
        this.bookPurchased = bookPurchased;
    }

    public int getBookPurchased() {
        return bookPurchased;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setBookPurchased(int bookPurchased) {
        this.bookPurchased = bookPurchased;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }
}
