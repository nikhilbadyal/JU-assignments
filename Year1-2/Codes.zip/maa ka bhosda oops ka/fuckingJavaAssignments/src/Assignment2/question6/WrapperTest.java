package Assignment2.question6;

public class WrapperTest {
    public static void main(String[] args){
        Integer i = Integer.valueOf(25);
        int x = i.intValue();
        System.out.println(i);
        System.out.println(x);

        //OR THIS CAN BE DONE AS

        Double j = 45.4;
        double y = j;
        System.out.println(j);
        System.out.println(y);

        //STRING TO BASIC TYPE

        String str = "45";
        int numericalString = Integer.parseInt(str);
        System.out.println(numericalString);

        //BASIC TO STRING TYPE

        String str2 = Integer.toString(495);
        System.out.println(str2);
    }
}
