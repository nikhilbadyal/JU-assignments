package Assignment2.question1;

public class Bank {
    private static final int creditLimitsNc=200000;
    private static final int creditLimitsPc=500000;

    public static boolean issueLoan(int amount, int currentLoanAmount, char tag) {
        if(tag == 'n')
           return issueloanNc(amount,currentLoanAmount);
        else
           return issueloanPc(amount,currentLoanAmount);

    }

    private static boolean issueloanPc(int amount, int currentLoanAmount) {
        if((amount+currentLoanAmount) > creditLimitsPc ) {
            System.out.println("Credit limit is less");
            return false;
        }
        else{
            System.out.println("Loan sanctioned");
            return true;
        }
    }



    private static boolean issueloanNc(int amount, int currentLoanAmount) {
        if((amount+currentLoanAmount) > creditLimitsNc ) {
            System.out.println("Credit limit is less");
            return false;
        }
        else{
            System.out.println("Loan sanctioned");
            return true;
        }
    }

    public static void showCreditLimit(char tag){
        if(tag == 'n')
            System.out.println("Normal customer : credit limit = "+creditLimitsNc);
        else
            System.out.println("Previleged customer : credit limit = "+creditLimitsPc);
    }

    public static void SeekAmount(char tag,int amount){
        if(tag == 'n')
            System.out.println("You can take "+(creditLimitsNc-amount));
        else
            System.out.println("You can take "+(creditLimitsPc-amount));
    }
}
