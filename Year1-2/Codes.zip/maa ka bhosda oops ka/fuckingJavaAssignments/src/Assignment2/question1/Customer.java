package Assignment2.question1;

public class Customer {
    private int id;
    private String name;
    private int currentLoanAmount;
    private String phoneNo;
    private char tag;

    public static int idgen=999;

    public Customer(String name, String phoneNo, char tag) {
        idgen++;
        this.id=idgen;
        this.currentLoanAmount = 0;
        this.name = name;
        this.phoneNo = phoneNo;
        this.tag=tag;
    }

    public void changeId(int id) {
        this.id = id;
    }

    public void changeName(String name) {
        this.name = name;
    }

    public void applyForLoan(int amount){
        if(Bank.issueLoan(amount,currentLoanAmount,tag))
            updateDetailsForLoan(amount);
    }

    public void updateDetailsForLoan(int amount){
        currentLoanAmount+=amount;
    }

    public int showCurrentLoanAmount() {
        System.out.println("Current loan amount = "+currentLoanAmount);
        return currentLoanAmount;
    }

    public void showSeekAmount(){
        Bank.SeekAmount(tag,currentLoanAmount);
    }

    public void showCreditLimit(){
        Bank.showCreditLimit(tag);
    }
}
