package Assignment2.question1;

public class Main {
    public static void main(String args[]){
        Customer c1 = new Customer("Aman","9682651543",'p');
        c1.applyForLoan(50000);
        c1.showCurrentLoanAmount();
        c1.showSeekAmount();

        Customer c2 = new Customer("Raman","7006210149",'n');
        c2.applyForLoan(50000);
        c2.showCurrentLoanAmount();
        c2.showSeekAmount();
    }
}
