package assignment1.question9;

public class Main {
    public static void main(String[] args){
        BankAcct acct = new BankAcct();

        acct.initIntRate(8);
        acct.displayIntRate();

        acct.changeIntRate(7);
        acct.displayIntRate();

    }
}
