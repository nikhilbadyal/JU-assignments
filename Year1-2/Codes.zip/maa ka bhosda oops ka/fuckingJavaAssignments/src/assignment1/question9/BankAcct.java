package assignment1.question9;

public class BankAcct {
    private double balance;
    private int number;
    static private double intRate = 5.0;

    public BankAcct(double balance, int number) {
        this.balance = balance;
        this.number = number;
    }
    public BankAcct(){
        this(0,0);
    }
    public void initIntRate(int value){
        intRate=value;
    }

    public double calInterest(double p,int time){
        double temp=(p*intRate*time)/100;
        return(temp);
    }

    public void changeIntRate(int value){
        intRate=value;
    }

    public void displayIntRate(){
        System.out.println(intRate);
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }


}
