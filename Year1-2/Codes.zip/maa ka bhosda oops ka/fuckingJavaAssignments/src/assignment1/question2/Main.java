package assignment1.question2;

public class Main {
    public static void main(String[] args){
        System.out.println("Command-Line arguments are : ");
        //Loop through all arguments
        for(String str: args) {
            System.out.println(str);
        }
    }
}
