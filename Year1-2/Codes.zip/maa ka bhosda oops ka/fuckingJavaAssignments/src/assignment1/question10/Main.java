package assignment1.question10;

public class Main {
}
