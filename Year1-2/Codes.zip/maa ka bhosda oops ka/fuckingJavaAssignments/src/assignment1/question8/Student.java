package assignment1.question8;

public class Student {
    private int roll;
    private double score;
    private String name;

    public Student(int roll, double score, String name) {
        this.roll = roll;
        this.score = score;
        this.name = name;
    }

    public Student(int roll, String name) {
        this(roll,0,name);
    }

    public Student(int roll) {
        this(roll,0,"no name");
    }
    public Student(){
        this(0,0,"no name");
    }

    public void copy(Student s){
        this.name=s.name;
        this.roll=s.roll;
        this.score=s.score;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRoll() {
        System.out.println(roll);
        return roll;
    }

    public double getScore() {
        System.out.println(score);
        return score;
    }

    public String getName() {
        System.out.println(name);
        return name;
    }
}
