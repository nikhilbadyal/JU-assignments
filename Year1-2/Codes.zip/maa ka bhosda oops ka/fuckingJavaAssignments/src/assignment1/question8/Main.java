package assignment1.question8;


public class Main {

    public static void main(String[] args) {
        Student s = new Student(5);


        s.setName("Aman");
        s.setRoll(2);
        s.setScore(33.5);

        s.getName();
        s.getRoll();
        s.getScore();

        Student s2 = new Student();
        s2.copy(s);

        s2.getName();
        s2.getRoll();
        s2.getScore();

    }
}