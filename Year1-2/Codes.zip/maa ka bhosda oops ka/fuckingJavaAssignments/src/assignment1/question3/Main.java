package assignment1.question3;

import java.util.Scanner;

public class Main{

    public static void main(String[] args){
        final double centimeterToFeet = 30.5;
        final double centimeterToInches = 2.54;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter height in centimeter (Integer Value)");
        int height = scanner.nextInt();
        int feet = (int) (height/centimeterToFeet);
        double height2 = height - (feet*centimeterToFeet);
        double inches = height2/centimeterToInches;
        System.out.println("Feet : " + feet + " Inches : " + inches);
        scanner.close();
    }
}
