package Assignment4.question1;
import java.util.Scanner;

public class Thread2 implements Runnable {
    IntegerType integer;

    public Thread2(IntegerType integer) {
        this.integer = integer;
        new Thread(this,"Thread 2").start();
    }

    @Override
    public void run() {
        integer.updateInteger(-10);
    }
}
