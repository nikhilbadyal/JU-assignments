package Assignment4.question1;

public class IntegerType {
    int num;

    public IntegerType(int num) {
        this.num = num;
    }
//  enter synchronised keyword for A4Q2
    public synchronized void updateInteger(int num){
        this.num += num;
        System.out.println("Value in "+ Thread.currentThread().getName() + " : " + this.num);
    }

    @Override
    public String toString() {
        return String.valueOf(num);
    }
}
