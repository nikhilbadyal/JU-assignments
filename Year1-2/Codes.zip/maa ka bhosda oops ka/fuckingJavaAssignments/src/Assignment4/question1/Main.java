package Assignment4.question1;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        IntegerType integer = new IntegerType(100);

         new Thread1(integer);
         new Thread2(integer);

    }
}
