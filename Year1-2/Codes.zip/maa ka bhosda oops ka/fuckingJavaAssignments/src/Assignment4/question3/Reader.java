package Assignment4.question3;

public class Reader implements Runnable {
    private Data data;
    public Reader(Data data ){
        this.data = data;
        new Thread(this,"Reader").start();
    }
    public void run(){
        while(true)
            data.read();
    }
}
