package Assignment4.question3;

public class Main {
    public static void main(String[] args) {
        Data data = new Data();
        new Writer(data);
        new Reader(data);
    }
}
