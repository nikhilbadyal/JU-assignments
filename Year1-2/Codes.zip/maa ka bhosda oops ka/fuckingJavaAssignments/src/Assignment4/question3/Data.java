package Assignment4.question3;

public class Data {
    private int data;
    private boolean empty = true;

    public synchronized void write(int d){
        while(!empty){
            try{
                wait();
            }catch(InterruptedException ie){
                System.out.println("Interrupted");
            }
        }

        this.data = d;
        empty = false;
        System.out.println("in write");
        System.out.println(data);
        notifyAll();
    }

    public synchronized int read(){
        while(empty){
            try{
                wait();
            }catch(InterruptedException ie){
                System.out.println("Interrupted");
            }
        }

        System.out.println("in read");
        System.out.println(data);
        empty = true;
        notifyAll();
        return data;
    }
}


