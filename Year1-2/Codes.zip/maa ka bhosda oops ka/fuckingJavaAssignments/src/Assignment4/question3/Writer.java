package Assignment4.question3;

import java.util.Scanner;

public class Writer implements Runnable {
   private Data data;
   public Writer(Data data){
       this.data = data;
       new Thread(this,"Writer").start();
   }
   public void run(){
       int i=0;
       while(i<10){
           data.write(i++);
       }
   }
}
