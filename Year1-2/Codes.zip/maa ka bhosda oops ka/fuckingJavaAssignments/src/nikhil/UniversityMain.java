package nikhil;

import javax.security.auth.callback.TextInputCallback;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * @author Nikhil
 * @date 13 Feb2020
 */

public class UniversityMain {
    public  static void main(String[] args) throws IOException {
        University myUniversity = new University();



        System.out.println("1 for Adding member.");
        System.out.println("2 for Removing member.");
        System.out.println("3 for Displaying member.");
        System.out.println("4 for Displaying member by code.");
        System.out.println("5 for Displaying all member.");
        System.out.println("6 for Sorting  member as per Name");
        System.out.println("7 for Sorting member as per Employee Code");
        System.out.println("8 for Sorting  member as per Department Code");
        System.out.println("9 for Sorting  member as per Basic Pay");
        System.out.println("10 for Sorting  member by natural ordering.");
        System.out.println("11 to exit.");

        int choice ;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        boolean status;
        boolean status1;

        while (true) {
            String str = "Enter choice : ";
            System.out.println(str);
            choice = 11;
            try{
                choice = Integer.parseInt(br.readLine());
            }catch (IOException | NumberFormatException io){
                io.getMessage();
            }
            switch (choice) {
                case 1:
                    System.out.println("Adding member");
                    if(myUniversity.addEmployeeRequest()) {
                    System.out.println("Member added.");
                    }else {
                        System.out.println("Member not added.");
                    }
                    break;
                case 2:
                    System.out.println("Removing member");
                    if(myUniversity.removeEmployeeRequest()){
                        System.out.println("Member removed.");
                    }else {
                        System.out.println("Unable to remove.");
                    }
                    break;
                case 3:
                    myUniversity.displayEmployee();
                    break;
                case 4:
                    System.out.println("Enter code :- ");
                    myUniversity.displayMember(Integer.parseInt(br.readLine()));
                    break;
                case 5:
                    System.out.println("Displaying all members :- ");
                    myUniversity.displayAllMembers();
                    break;
                case 6:
                    System.out.println("Sorting by name :- ");
                    String condition = "Name";
                    status = true;
                    status1 = false;
                    myUniversity.sortEmployee(condition, status);
                    myUniversity.displayAllMembers();
                    break;
                case 7:
                    System.out.println("Sorting by Emp code  :- ");
                    condition = "Employee Code";
                    status = true;
                    status1 = false;
                    myUniversity.sortEmployee(condition, status);
                    myUniversity.displayAllMembers();
                    myUniversity.sortEmployee(condition, status1);
                    myUniversity.displayAllMembers();
                    break;
                case 8:
                    System.out.println("Sorting by Dept code  :- ");
                    condition = "Department Code";
                    status = true;
                    status1 = false;
                    myUniversity.sortEmployee(condition, status);
                    myUniversity.displayAllMembers();
                    myUniversity.sortEmployee(condition, status1);
                    myUniversity.displayAllMembers();
                    break;
                case 9:
                    System.out.println("Sorting by Basic pay :- ");
                    condition = "Basic Pay";
                    status = true;
                    status1 = false;
                    myUniversity.sortEmployee(condition, status);
                    myUniversity.displayAllMembers();
                    myUniversity.sortEmployee(condition, status1);
                    myUniversity.displayAllMembers();
                    break;
                case 10:
                    System.out.println("Sorting by Natural order  :- ");
                    myUniversity.sortEmployee();
                    myUniversity.displayAllMembers();
                    break;
                case  11:
                    System.exit(0);
                default:
                    System.out.println("please enter properly.");
                    break;
            }
        }

      //  System.out.println(myUniversity.addEmployeeRequest());








        //myUniversity.updateMemberDetailsRequest();
        /*
        String condition = "Name";


        myUniversity.sortEmployee(condition,status1);
        myUniversity.displayAllMembers();



        condition = "Department Code";
        status = true;
        status1 = false;
        myUniversity.sortEmployee(condition,status);
        myUniversity.displayAllMembers();
        myUniversity.sortEmployee(condition,status1);
        myUniversity.displayAllMembers();*/



      /*
        myUniversity.sortEmployee(true);
        myUniversity.displayAllMembers();
        myUniversity.sortEmployee(false);
        myUniversity.displayAllMembers();*/
    }
}
   
