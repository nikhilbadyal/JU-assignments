package Assignment3.question01;

import java.util.*;

public class EmployeeList {
    private List<Employee> empList;
    static final Comparator<Employee> empCodeOrder;
    static final Comparator<Employee> empBasicOrder;
    static final Comparator<Employee> empDeptCodeOrder;

    static {
        empCodeOrder = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                if (e1.getCode() > e2.getCode())
                    return 1;
                else if (e1.getCode() < e2.getCode())
                    return -1;
                else
                    return 0;
            }
        };

        empBasicOrder = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                if (e1.getBasicCode() > e2.getBasicCode())
                    return 1;
                else if (e1.getBasicCode() < e2.getBasicCode())
                    return -1;
                else
                return 0;
            }
        };

        empDeptCodeOrder = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                if (e1.getDeptCode() > e2.getDeptCode())
                    return 1;
                else if (e1.getDeptCode() < e2.getDeptCode())
                    return -1;
                else
                return 0;
            }
        };
    }



    public EmployeeList(){
        empList = new LinkedList<>();
    }

    public boolean addEmployee(int code, String name, int basicCode, int deptCode){
        Employee e = new Employee(code,name,basicCode,deptCode);
        if(empList.contains(e)){
            return false;
        } else {
            empList.add(e);
            return true;
        }
    }
    public void showEmployeeList(){
        for(Employee e : empList){
            System.out.println('\n' + "Employee code : " + e.getCode() + '\n' +
                                "Employee name : " + e.getName() + '\n' +
                               "Employee basic code : " + e.getBasicCode() + '\n' +
                               "Employee department code : " + e.getDeptCode() + '\n'
                               );
        }
    }

    public boolean removeEmployee(int id){
        for(Employee e : empList){
            if(e.getCode() == id){
                empList.remove(e);
                return true;
            }
        }
        return false;
    }

    public boolean modifyBasic(int id,int newCode){
        for(Employee e: empList){
            if(e.getCode() == id){
                e.setBasicCode(newCode);
                return true;
            }
        }
        return false;
    }

    public void sortEmployeeListInCodeOrder(){
        Collections.sort(empList,empCodeOrder);
    }

    public void sortEmployeeListInBasicCodeOrder(){
        Collections.sort(empList,empBasicOrder);
    }

    public void sortEmployeeListInDeptCodeOrder(){
        Collections.sort(empList,empDeptCodeOrder);
    }
}
