package Assignment3.question01;

public class Department {
    private int code;
    private String name;
    private String loc;

    public Department(int code, String name, String loc) {
        this.code = code;
        this.name = name;
        this.loc = loc;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getLoc() {
        return loc;
    }

    public boolean equals(Object o) {
        if(o == null){
            return  false;
        }
        if(o instanceof Department){
            if(this.getCode() == ((Department) o).getCode()){
                return true;
            }
        }
        return false;
    }

    public String toString(){
        return ("Department code : " + this.getCode() + '\n' +
                "Department name : " + this.getName() + '\n' +
                "Department location : " + this.getLoc()
        );
    }
}
