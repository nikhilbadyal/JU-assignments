package Assignment3.question01;

public class Main {
    public static  void main(String[] args){
        EmployeeList e = new EmployeeList();
        e.addEmployee(2,"aman",84,65);
        e.addEmployee(1,"raman",45,5);
        e.addEmployee(7,"Nikhil",76,3);
       /* e.showEmployeeList();

        e.showEmployeeList();
        e.removeEmployee(2);
        e.showEmployeeList();*/

       // e.sortEmployeeListInBasicCodeOrder();
        //e.showEmployeeList();
        //System.out.println('\n' + '\n');
      //  e.sortEmployeeListInCodeOrder();
       // e.showEmployeeList();
        //System.out.println('\n' + '\n');
        e.sortEmployeeListInDeptCodeOrder();
        e.showEmployeeList();
        //System.out.println('\n' + '\n');
//        DepartmentList d = new DepartmentList();
//        d.addDept(99,"raman","biramgarh");
//        d.addDept(1,"aman","biramgarh");
//
//
//        d.showDepartmentList();
    }
}
