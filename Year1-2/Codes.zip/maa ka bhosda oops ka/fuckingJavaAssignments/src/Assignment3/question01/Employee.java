package Assignment3.question01;

public class Employee {
    private int code;
    private String name;
    private int basicCode;
    private  int deptCode;

    public Employee(int code, String name, int basicCode, int deptCode) {
        this.code = code;
        this.name = name;
        this.basicCode = basicCode;
        this.deptCode = deptCode;
    }

    public void setBasicCode(int basicCode) {
        this.basicCode = basicCode;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public int getBasicCode() {
        return basicCode;
    }

    public int getDeptCode() {
        return deptCode;
    }

    @Override
    public boolean equals(Object o) {
        if(o == null){
            return  false;
        }
        if(o instanceof Employee){
            return this.getCode() == ((Employee) o).getCode();
        }
        return false;
    }
}
