package Assignment3.question01;

import java.util.ArrayList;

public class DepartmentList {
    private ArrayList<Department> deptList;

    public DepartmentList(){
        deptList = new ArrayList<>();
    }

    public boolean addDept(int code,String name,String loc){
        Department d = new Department(code,name,loc);

        if(deptList.contains(d)){
            return false;
        }else{
            deptList.add(d);
            return true;
        }
    }

    public void showDepartmentList(){
        for(Department d : deptList){
            System.out.println(d);
        }
    }

}
