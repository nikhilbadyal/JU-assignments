package Assignment3.question03;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Scanner;

class MyFilter implements FilenameFilter {

    @Override
    public boolean accept(File dir, String name) {
        return name.endsWith(".log");
    }
}
public class FileCheck {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter file name : ");
        try{
            String s = scanner.nextLine();
            File fileStream = new File(s);
            if(fileStream.exists()){
                System.out.println("Path exists");
                if(fileStream.isDirectory()) {
                    System.out.println("Yes it is directory");
                    String[] str = fileStream.list(new MyFilter());
                    if(str!=null){
                        for(String x : str){
                            System.out.println(x);
                        }
                    }
                }
                else
                    System.out.println("No its not a directory");
            } else
                System.out.println("Path does not exist");
        }catch (NullPointerException nullError){
            System.out.println(nullError.getMessage());
        }
    }
}
