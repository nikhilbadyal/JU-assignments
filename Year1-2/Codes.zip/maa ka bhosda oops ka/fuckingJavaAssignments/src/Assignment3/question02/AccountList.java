package Assignment3.question02;

import java.util.HashMap;
import java.util.Map;

public class AccountList {
    private Map<Integer,Account> accList = new HashMap<>();

    public boolean addAccount(int AccountId,String name){
        if(!accList.containsKey(AccountId)){
            accList.put(AccountId,new Account(name,0));
            return true;
        }
        return false;
    }

    public int checkBalance(int accId) throws MyException {
        if (accList.containsKey(accId)) {
            return accList.get(accId).getBalance();
        }else {
            throw new MyException(accId);
        }
    }

    public Map showAccountList(){
        return new HashMap(accList);
    }
}
