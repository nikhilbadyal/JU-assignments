package Assignment3.question02;

import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        AccountList a = new AccountList();
        while(true){
            System.out.println("1.ADD ACCOUNT \n" +
                               "2.CHECK BALANCE \n" +
                               "3.DISPLAY ALL ACCOUNTS \n" +
                               "4.UUPDATE BALANCE \n" + 
                               "4.ENTER YOU CHOICE : ");
            int id;
            String name;
            int ch = scanner.nextInt();

            System.out.println("\n\n");

            switch(ch){
                case 1 :
                    System.out.println("Enter account id : ");
                    id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Enter name of account holder : ");
                    name = scanner.nextLine();

                    if(a.addAccount(id,name)){
                        System.out.println("Account Added Successfully");
                    }
                    else{
                        System.out.println("Account can't be added\nACCOUNT NUMBER ALREADY EXIST");
                    }

                    break;

                case 2 :
                    System.out.println("Enter Account Id : ");
                    id = scanner.nextInt();

                    try{
                        System.out.println("Your balance is : " + a.checkBalance(id));
                    }catch(MyException e){
                        System.out.println(e);
                    }
                    break;

                case 3 :
                    Map<Integer,Account> acc = a.showAccountList();

                    for(int i : acc.keySet()){
                        System.out.println("Account number : " + i + '\n' +
                                "Account name : " + acc.get(i).getName() + '\n' +
                                "Account Balance : " + acc.get(i).getBalance());
                        System.out.println();
                    }
                    break;

                default :
                    System.out.println("YOU HAVE ENTERED A WRONG NUMBER");
                    break;

            }
        }
//        AccountList a = new AccountList();
//        a.addAccount(45,"aman");
//        a.addAccount(32,"raman");
//        try{
//            a.checkBalance(45);
//        }catch(MyException e){
//            System.out.println(e);
//        }
//        try{
//            a.checkBalance(65);
//        }catch(MyException e){
//            System.out.println(e);
//        }
//
//        Map<Integer,Account> acc = a.showAccountList();
//        for(int i : acc.keySet()){
//                        System.out.println("Account number : " + i + '\n' +
//                                "Account name : " + acc.get(i).getName() + '\n' +
//                                "Account Balance : " + acc.get(i).getBalance());
//                        System.out.println();
//                    }

    }
}
