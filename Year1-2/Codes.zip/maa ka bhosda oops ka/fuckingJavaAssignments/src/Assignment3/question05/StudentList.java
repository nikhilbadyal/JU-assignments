package Assignment3.question05;

import java.io.*;

import java.util.Scanner;

public class StudentList {
    private Student s;

    public void addStudent()  {

        Scanner scanner = new Scanner(System.in);
        try(ObjectOutputStream stuFile = new ObjectOutputStream(new FileOutputStream("Student.dat"))) {
            String name;
            int roll, score,n;
            System.out.println("\nEnter total number of students");
            n = scanner.nextInt();
            scanner.nextLine();

            for(int i=0;i<n;i++){
                System.out.println("Enter details of student");
                System.out.println("Name : ");
                name = scanner.nextLine();
                System.out.println("Roll : ");
                roll = scanner.nextInt();
                System.out.println("Score : ");
                score = scanner.nextInt();
                scanner.nextLine();

                Student s = new Student(name,roll,score);

                stuFile.writeObject(s);
            }

        }catch(IOException io){
            System.out.println("Add IoException " + io.getMessage());
        }
    }

    public void displayStudent(){
        try(ObjectInputStream stuFile = new ObjectInputStream(new BufferedInputStream(new FileInputStream("Student.dat")))){
            boolean eof = false;
            while(!eof) {
                try {
                    s = (Student) stuFile.readObject();
                    s.display();
                } catch (EOFException e) {
                    eof = true;
                }
            }
    }
        catch(ClassNotFoundException e) {
            System.out.println("ClassNotFoundException " + e.getMessage());
        }catch(IOException io){
            System.out.println("IoException " + io.getMessage());
        }
    }
}
