package Assignment3.question05;


import java.util.Scanner;

public class Main {

    public static void main(String[]args) {
        Scanner scanner = new Scanner(System.in);
        StudentList s = new StudentList();
        while(true){
            int choice;
            System.out.println("Enter 1 to add Student: \n" +
                               "Enter 2 to display all Student : \n" +
                               "Enter your choice : ");

            choice = scanner.nextInt();
            switch(choice){
                case 1: s.addStudent();
                        break;

                case 2 : s.displayStudent();
                         break;

                default :
                    System.out.println("you have enter the wrong number : ");
                    break;
            }
        }
        //s.addStudent("raman",78,100);
    }
}
