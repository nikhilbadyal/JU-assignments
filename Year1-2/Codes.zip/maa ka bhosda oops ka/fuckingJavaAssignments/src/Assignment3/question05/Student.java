package Assignment3.question05;

import java.io.Serializable;

public class Student implements Serializable {
    private final String name;
    private final int roll;
    private final int score;
    private static final long SerialVersionUId = 1L;

    public Student(String name,int roll,int score){
        this.name = name;
        this.roll = roll;
        this.score = score;
    }

    public void display(){
        System.out.println("\n\n\nName : " + name + "\n" +
                           "roll : " + roll + "\n" +
                           "score : " + score);
    }
    public String getName() {
        return name;
    }

    public int getRoll() {
        return roll;
    }

    public int getScore() {
        return score;
    }
}
