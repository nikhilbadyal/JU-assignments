package Assignment3.question04;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class question04 {
    public static void main(String[] args) {
        System.out.println("Enter total number of names that you want to enter : ");
        try(BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in)); 
            FileWriter fileOutputStream = new FileWriter("C:\\Users\\amans\\Downloads\\" +
                    "fuckingJavaAssignments\\src\\Assignment3\\question04\\Aman.txt")){


            int noOfName = Integer.parseInt(bufferedReader.readLine());
            int i = 0 ;
            while (i != noOfName){
                fileOutputStream.write(bufferedReader.readLine()+"\n");
                i++;
            }

        }catch(NumberFormatException  wrongData){
            System.out.println("Please enter data properly.");
        } catch (IOException ioError) {
            System.out.println(ioError.getMessage());
        }
    }
}
