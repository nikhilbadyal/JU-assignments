import java.util.Map;
public class A3Q2 {
    public static void main(String[] args){
        AccountList a = new AccountList();
        a.addAccount(1,"aman");
        a.addAccount(1,"aman");
        a.addAccount(2,"raman");

        try{a.checkBalance(5);}
        catch(MyException e){
            System.out.println(e);
        }

        Map<Integer,Account> acc = a.showAccountList();

        for(Integer i : acc.keySet()){
            System.out.println("Account number : " + i + '\n' +
                    "Account name : " + acc.get(i).getName() + '\n' +
                    "Account Balance : " + acc.get(i).getBalance());
            System.out.println();
        }

    }
}