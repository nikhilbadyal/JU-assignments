public class MyException extends Exception{
    private int accountId;

    public MyException(int accountId) {
        this.accountId = accountId;
    }
    public String toString(){
        return "My Exception : This account does not exist";
    }
}