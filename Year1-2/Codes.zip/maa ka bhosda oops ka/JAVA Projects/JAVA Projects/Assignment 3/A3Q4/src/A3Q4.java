import java.io.*;
import java.util.Scanner;

public class A3Q4 {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        int size,i;
        System.out.println("How many lines would you like to enter : ");
        size = scanner.nextInt();scanner.nextLine();
        String[] stringList = new String[size];
        String fileName = "./Question4.txt",string;
        System.out.println("Enter the Strings : ");
        for(i=0;i<size;i++)
            stringList[i] = scanner.nextLine();
        File file = new File(fileName);
        file.delete();
        file.createNewFile();
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileName,true));
        for(i=0;i<size;i++)
            bufferedWriter.write(stringList[i]+"\n");
        bufferedWriter.close();
        BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
        while((string = bufferedReader.readLine()) != null){
            System.out.println(string);
        }
        bufferedReader.close();
    }
}
