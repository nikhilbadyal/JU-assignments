import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        DepartmentList departmentList = new DepartmentList();
        EmployeeList employeeList = new EmployeeList();
        mainMenu(departmentList,employeeList);
    }

    static void mainMenu(DepartmentList departmentList,EmployeeList employeeList){
        Scanner scanner = new Scanner(System.in);
        int choice;
        while(true) {
            System.out.println("Enter your option : ");
            System.out.println("1.Add Employee\n2.Add Department\n3.Show Employee\n4.Employee List");
            System.out.println("5.Total Basic Pay of a Department\n6.Remove Employee\n7.Modify Employee");
            System.out.println("8.Sort Employee List\n0.Exit");
            choice = scanner.nextInt();scanner.nextLine();
            switch (choice) {
                case 1:
                    employeeList.addEmployee(departmentList);
                    break;
                case 2:
                    departmentList.addDepartment();
                    break;
                case 3:
                    employeeList.showEmployee(departmentList);
                    break;
                case 4:
                    employeeList.showEmployeeList(departmentList);
                    break;
                case 5:
                    departmentList.showBasicPay(employeeList);
                    break;
                case 6:
                    employeeList.removeEmployee();
                    break;
                case 7:
                    employeeList.modifyEmployee(departmentList);
                    break;
                case 8:
                    employeeList.sortEmployeeList(departmentList);
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Invalid Input!!!");
            }
        }
    }
}
