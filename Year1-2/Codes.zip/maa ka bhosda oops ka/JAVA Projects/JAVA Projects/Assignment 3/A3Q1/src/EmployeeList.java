import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class EmployeeList {
    ArrayList<Employee> employeeArrayList = new ArrayList<>();
    static final Comparator<Employee> employeeCode = new Comparator<Employee>() {
        @Override
        public int compare(Employee o1, Employee o2) {
            if(o1.getEmpCode() > o2.getEmpCode())
                return 1;
            else if(o1.getEmpCode() < o2.getEmpCode())
                return -1;
            return 0;
        }
    };

    static final Comparator<Employee> employeeBasicPay = new Comparator<Employee>() {
        @Override
        public int compare(Employee o1, Employee o2) {
            if(o1.getBasic() > o2.getBasic())
                return 1;
            else if(o1.getBasic() < o2.getBasic())
                return -1;
            return 0;
        }
    };

    static final Comparator<Employee> departmentCode = new Comparator<Employee>() {
        @Override
        public int compare(Employee o1, Employee o2) {
            if(o1.getDeptCode() > o2.getDeptCode())
                return 1;
            else if(o1.getDeptCode() < o2.getDeptCode())
                return -1;
            return 0;
        }
    };

    public void addEmployee(DepartmentList departmentList){

        if(departmentList.departmentArrayList.isEmpty()){
            System.out.println("No Departments Added, Can't Add Employees!!!");
            return;
        }
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Employee Code : ");
        int empCode,deptCode;
        empCode = scanner.nextInt();scanner.nextLine();
        Employee employee = new Employee(empCode);
        if(employeeArrayList.contains(employee)){
            System.out.println("Employee Code not Unique!!!");
            return;
        }
        double basic;
        String name;
        System.out.println("Enter Department Code : ");
        deptCode = scanner.nextInt();scanner.nextLine();
        Department department = new Department(deptCode);
        if(!departmentList.departmentArrayList.contains(department)){
            System.out.println("Department Doesn't Exist!!!");
            return;
        }
        System.out.println("Enter Name : ");
        name = scanner.nextLine();
        System.out.println("Enter Basic : ");
        basic = scanner.nextDouble();scanner.nextLine();
        employee = new Employee(empCode,deptCode,name,basic);
        employeeArrayList.add(employee);
    }

    public void showEmployee(DepartmentList departmentList){
        int empCode,index;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Employee Code : ");
        empCode = scanner.nextInt();scanner.nextLine();
        Employee employee = new Employee(empCode);
        index = employeeArrayList.indexOf(employee);
        if(index == -1){
            System.out.println("Employee doesn't Exist!!!");
            return;
        }
        System.out.println("Employee Details :\n" + employeeArrayList.get(index));
        int deptCode = employee.getDeptCode();
        Department department = new Department(deptCode);
        index = departmentList.departmentArrayList.indexOf(department);
        System.out.println("Department : " + departmentList.departmentArrayList.get(index));
    }

    public void showEmployeeList(DepartmentList departmentList){
        Department department = new Department();
        int i,index;
        for(i=0;i<employeeArrayList.size();i++){
            System.out.println("Employee No." + (i+1) + "\n" + employeeArrayList.get(i));
            department = new Department(employeeArrayList.get(i).getDeptCode());
            index = departmentList.departmentArrayList.indexOf(department);
            System.out.println("Department : \n" + departmentList.departmentArrayList.get(index));
        }
    }

    public void removeEmployee(){
        Scanner scanner = new Scanner(System.in);
        int index,empCode;
        System.out.println("Enter Employee Code : ");
        empCode = scanner.nextInt();scanner.nextLine();
        if((index = employeeArrayList.indexOf(new Employee(empCode))) == -1){
            System.out.println("Employee Doesn't Exist!!!");
            return;
        }
        employeeArrayList.remove(index);
    }

    public void modifyEmployee(DepartmentList departmentList){
        Scanner scanner = new Scanner(System.in);
        int index,empCode,deptCode;
        String name;
        double basic;
        System.out.println("Enter Employee Code : ");
        empCode = scanner.nextInt();scanner.nextLine();
        if((index = employeeArrayList.indexOf(new Employee(empCode))) == -1){
            System.out.println("Employee Doesn't Exist!!!");
            return;
        }
        System.out.println("Enter Department Code : ");
        deptCode = scanner.nextInt();scanner.nextLine();
        Department department = new Department(deptCode);
        if(!departmentList.departmentArrayList.contains(department)){
            System.out.println("Department Doesn't Exist!!!");
            return;
        }
        System.out.println("Enter Name : ");
        name = scanner.nextLine();
        System.out.println("Enter Basic : ");
        basic = scanner.nextDouble();scanner.nextLine();
        Employee employee = new Employee(empCode,deptCode,name,basic);
        employeeArrayList.set(index,employee);
    }

    public void sortEmployeeList(DepartmentList departmentList){
        Scanner scanner = new Scanner(System.in);
        int choice;
        while(true) {
            System.out.println("1.Employee Code\n2.Department Code\n3.Basic Pay\n0.Main Menu");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    Collections.sort(employeeArrayList, employeeCode);
                    break;
                case 2:
                    Collections.sort(employeeArrayList, departmentCode);
                    break;
                case 3:
                    Collections.sort(employeeArrayList, employeeBasicPay);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid Input!!!");
            }
            showEmployeeList(departmentList);
        }
    }
}
