public class Department {
    private int code;
    private String name;
    private String location;

    public Department(int code){
        this(code,null,null);
    }

    public Department(){
        this(0,null,null);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Department){
            if(code == ((Department)obj).getCode())
                return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return ("Name : " + getName() + " Code : " + getCode() + "\nLocation : " + getLocation());
    }

    public Department(int code, String name, String location) {
        this.code = code;
        this.name = name;
        this.location = location;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

}
