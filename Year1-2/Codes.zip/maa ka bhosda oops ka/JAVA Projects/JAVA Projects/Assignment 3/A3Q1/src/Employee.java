public class Employee {
    int empCode;
    int deptCode;
    String name;
    double basic;

    public Employee() {
        this(0,0,null,0.0);
    }

    public Employee(int empCode) {
        this(empCode,0,null,0.0);
    }

    public Employee(int empCode, int deptCode, String name, double basic) {
        this.empCode = empCode;
        this.deptCode = deptCode;
        this.name = name;
        this.basic = basic;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Employee){
            if(empCode == ((Employee)obj).getEmpCode())
                return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return ("Name : " + getName() + " Employee Code : " + getEmpCode() + " Basic : " + getBasic());
    }

    public int getEmpCode() {
        return empCode;
    }

    public int getDeptCode() {
        return deptCode;
    }

    public String getName() {
        return name;
    }

    public double getBasic() {
        return basic;
    }
}
