import java.util.ArrayList;
import java.util.Scanner;

public class DepartmentList {
    ArrayList<Department> departmentArrayList = new ArrayList<>();
    public void addDepartment(){
        Scanner scanner = new Scanner(System.in);
        int code;
        System.out.println("Enter Department Code(integer) : ");
        code = scanner.nextInt();scanner.nextLine();
        Department department = new Department(code);
        if(departmentArrayList.contains(department)){
            System.out.println("Department Code not unique!!!");
            return;
        }
        else{
            System.out.println("Enter name : ");
            String name = scanner.nextLine();
            System.out.println("Enter Location : ");
            String location = scanner.nextLine();
            department = new Department(code,name,location);
            departmentArrayList.add(department);
        }
    }

    public void showBasicPay(EmployeeList employeeList){
        Scanner scanner = new Scanner(System.in);
        int code,index,i;
        double basicPay = 0.0;
        Department department = new Department();
        System.out.println("Enter Department Code to Calculate Basic Pay");
        code = scanner.nextInt();scanner.nextLine();
        department = new Department(code);
        if((index = departmentArrayList.indexOf(department)) == -1){
            System.out.println("Department doesn't Exist!!!");
        }
        for(i=0;i<employeeList.employeeArrayList.size();i++){
            if(code == employeeList.employeeArrayList.get(i).getDeptCode())
                basicPay += employeeList.employeeArrayList.get(i).getBasic();
        }
        System.out.println("Basic Pay of the Department is : " + basicPay);
    }
}
