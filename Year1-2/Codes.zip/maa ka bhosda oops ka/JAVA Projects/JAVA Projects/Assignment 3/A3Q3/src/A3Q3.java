import java.io.File;
import java.util.Scanner;

public class A3Q3 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter file name : ");
        try{
            String s = scanner.nextLine();
            File fileStream = new File(s);
            if(fileStream.exists()){
                System.out.println("Path exists");
                if(fileStream.isDirectory()) {
                    System.out.println("Yes it is directory");
                    String[] str = fileStream.list(null);
                    if(str!=null){
                        for(String x : str){
                            System.out.println(x);
                        }
                    }
                }
                else
                    System.out.println("No its not a directory");
            } else
                System.out.println("Path does not exist");
        }catch (NullPointerException nullError){
            System.out.println(nullError.getMessage());
        }
    }
}