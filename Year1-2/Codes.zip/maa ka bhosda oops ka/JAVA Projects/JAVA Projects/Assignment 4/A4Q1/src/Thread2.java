import java.util.Scanner;

public class Thread2 extends Thread {
    IntegerType integer;

    public Thread2(IntegerType integer) {
        this.integer = integer;
    }

    @Override
    public void run() {
        integer.updateInteger(-10);
        //System.out.println("Thread 2 , Integer : " + integer);
    }
}
