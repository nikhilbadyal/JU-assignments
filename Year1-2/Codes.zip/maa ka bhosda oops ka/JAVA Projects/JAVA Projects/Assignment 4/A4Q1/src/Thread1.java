import java.util.Scanner;

public class Thread1 extends Thread {
    IntegerType integer;

    public Thread1(IntegerType integer) {
        this.integer = integer;
    }

    @Override
    public void run() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter Value for Incrementation : ");
//        int num = scanner.nextInt();scanner.nextLine();
        integer.updateInteger(100);
        //System.out.println("Thread 1 , Integer : " + integer);
    }
}
