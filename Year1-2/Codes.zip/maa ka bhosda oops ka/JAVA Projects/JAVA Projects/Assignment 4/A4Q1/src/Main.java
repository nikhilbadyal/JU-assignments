import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        IntegerType integer = new IntegerType(100);
//        System.out.println("Enter the fixed Integer : ");
//        Integer integer = scanner.nextInt();scanner.nextLine();
        Thread1 thread1 = new Thread1(integer);
        Thread2 thread2 = new Thread2(integer);
        thread1.setName("Thread1");
        thread2.setName("Thread2");
        thread1.start();
        thread2.start();
        for(int i = 1 ; i<10 ; i++)
        System.out.println("After Simultaneous Call " + i + " , Integer Value : " + integer);
    }
}
