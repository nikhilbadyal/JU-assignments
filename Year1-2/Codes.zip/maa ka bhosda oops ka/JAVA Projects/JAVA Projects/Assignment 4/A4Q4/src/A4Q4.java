import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class A4Q4 {
    public static void main(String[] args) {
        EmployeeList employeeList = new EmployeeList();
        //employeeList.addMember();
        //employeeList.searchMember();
        mainMenu(employeeList);
    }

    static void mainMenu(EmployeeList employeeList){
        JFrame jFrame = new JFrame("Main Menu");
        jFrame.setVisible(true);
        jFrame.setSize(300,200);
        jFrame.setLocationRelativeTo(null);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton addMemberButton = new JButton("Add Member");
        JButton searchMemberButton = new JButton("Search Member");
        jFrame.add(addMemberButton);
        jFrame.setLayout(null);
        jFrame.add(searchMemberButton);

        addMemberButton.setBounds(45,50,200,20);
        searchMemberButton.setBounds(45,80,200,20);





        addMemberButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                employeeList.addMember();
            }
        });

        searchMemberButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                employeeList.searchMember();
            }
        });

    }
}
