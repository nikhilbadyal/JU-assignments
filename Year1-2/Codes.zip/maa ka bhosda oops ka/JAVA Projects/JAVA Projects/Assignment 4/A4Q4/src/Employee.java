public class Employee {
    private int empCode;
    private String empName;
    private double basicSalary;
    private char grade;
    private int deptCode;

    public Employee(int empCode){
        this.empCode = empCode;
    }

    public Employee(){}

    @Override
    public boolean equals(Object obj) {
        if( obj instanceof Employee){
            if(((Employee)obj).getEmpCode() == empCode)
                return true;
        }
        return false;
    }

    public int getEmpCode() {
        return empCode;
    }

    public void setEmpCode(int empCode) {
        this.empCode = empCode;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public char getGrade() {
        return grade;
    }

    public void setGrade(char grade) {
        this.grade = grade;
    }

    public int getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(int deptCode) {
        this.deptCode = deptCode;
    }
}
