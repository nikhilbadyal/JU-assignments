import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class EmployeeList {
    private List<Employee> employeeList  = new LinkedList<Employee>();

    public void addMember(){
        JFrame jFrame;
        JButton saveButton;
        JRadioButton gA,gB,gC;
        JLabel label1,label2,label3,label4,label5,label6;
        JTextField tx1,tx2,tx3;
        jFrame = new JFrame("Adding Employee");
        label1 = new JLabel("Enter Employee Details");

        label1.setBounds(120,5,200,60);
        label2 = new JLabel("Name");
        label2.setBounds(5,55,150,50);
        tx1 = new JTextField();
        tx1.setBounds(150,73,200,20);

        label3 = new JLabel("Employee Code");
        label3.setBounds(5,85,150,50);
        tx2 = new JTextField();
        tx2.setBounds(150,100,200,20);

        label4 = new JLabel("Basic Salary");
        label4.setBounds(5,115,150,50);
        tx3 = new JTextField();
        tx3.setBounds(150,130,200,20);

        label5 = new JLabel("Department");
        label5.setBounds(5,145,150,50);


        DefaultListModel l1 = new DefaultListModel<>();
        l1.addElement("Department 1");
        l1.addElement("Department 2");
        l1.addElement("Department 3");
        l1.addElement("Department 4");
        final JList list = new JList<>(l1);
        list.setBounds(150,160, 110,75);

        label6 = new JLabel("Grade");
        label6.setBounds(5,235,50,50);
        gA = new JRadioButton("A");
        gB = new JRadioButton("B");
        gC = new JRadioButton("C");

        gA.setBounds(150,235,40,35);
        gB.setBounds(190,235,40,35);
        gC.setBounds(230,235,40,35);
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(gA);buttonGroup.add(gB);buttonGroup.add(gC);

        saveButton = new JButton("Save");
        saveButton.setBounds(120,325,150,50);

        jFrame.setSize(400,450);
        jFrame.setLayout(null);
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);
        //jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jFrame.add(label1);jFrame.add(label2);jFrame.add(label3);jFrame.add(label4);
        jFrame.add(label5);jFrame.add(label6);
        jFrame.add(tx1);jFrame.add(tx2);jFrame.add(tx3);
        jFrame.add(list);
        jFrame.add(gA);jFrame.add(gB);jFrame.add(gC);
        jFrame.add(saveButton);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int s = JOptionPane.showConfirmDialog(jFrame, "Are you Sure?");
                if (s == JOptionPane.YES_OPTION) {
                    int empCode,deptCode;
                    String empName;
                    double basicSalary;
                    char grade;
                    empCode = Integer.parseInt(tx2.getText());
                    if(!employeeList.contains(new Employee(empCode))){
                        Employee employee = new Employee();
                        empName = tx1.getText();
                        basicSalary = Double.parseDouble(tx3.getText());
                        if(gA.isSelected()){
                            grade = 'A';
                        }else if(gB.isSelected()){
                            grade = 'B';
                        }else if(gC.isSelected()){
                            grade = 'C';
                        }else{
                            grade = 'Z';
                        }
                        deptCode = list.getSelectedIndex()+1;
                        employee.setBasicSalary(basicSalary);
                        employee.setDeptCode(deptCode);
                        employee.setEmpCode(empCode);
                        employee.setGrade(grade);
                        employee.setEmpName(empName);
                        employeeList.add(employee);
                    }else{
                        JOptionPane.showMessageDialog(jFrame,"Employee Code not Unique!!!","Duplicate Data",JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        });
    }

    public void searchMember(){
        JLabel label1 = new JLabel("Employee Code");
        JLabel label2 = new JLabel();
        JLabel empCodeLabel = new JLabel();
        JLabel empNameLabel = new JLabel();
        JLabel empBasicSalaryLabel = new JLabel();
        JLabel empGradeLabel = new JLabel();
        JLabel empDeptCodeLabel = new JLabel();
        JTextField textField1 = new JTextField();
        JButton button = new JButton("Search");
        JFrame jFrame = new JFrame("Search Employee");

        jFrame.setLayout(null);
        jFrame.setSize(300,250);
        jFrame.setLocationRelativeTo(null);
        label1.setBounds(20,10,150,20);
        textField1.setBounds(140,10,120,20);
        label2.setBounds(90,100,200,20);
        empNameLabel.setBounds(20,120,180,20);
        empCodeLabel.setBounds(200,120,100,20);
        empDeptCodeLabel.setBounds(20,140,180,20);
        empGradeLabel.setBounds(200,140,100,20);
        empBasicSalaryLabel.setBounds(20,160,180,20);
        button.setBounds(90,40,100,20);


        jFrame.add(label1);jFrame.add(label2);jFrame.add(empCodeLabel);jFrame.add(empDeptCodeLabel);
        jFrame.add(empNameLabel);jFrame.add(empBasicSalaryLabel);jFrame.add(empGradeLabel);
        jFrame.add(textField1);
        jFrame.add(button);
        jFrame.setVisible(true);

        //jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int empCode = Integer.parseInt(textField1.getText());
                if(!employeeList.contains(new Employee(empCode))){
                    JOptionPane.showMessageDialog(null,"Employee corresponding to the given Employee code not present",
                                                "Employee not found",JOptionPane.WARNING_MESSAGE);
                }
                else{
                    int index = employeeList.indexOf(new Employee(empCode));
                    Employee employee = employeeList.get(index);
                    label2.setText("Employee Details");
                    empCodeLabel.setText("Code : " + employee.getEmpCode());
                    empNameLabel.setText("Name : " + employee.getEmpName());
                    empGradeLabel.setText("Grade : " + employee.getGrade());
                    empBasicSalaryLabel.setText("Basic Salary : " + employee.getBasicSalary());
                    int deptCode = employee.getDeptCode();
                    switch(deptCode){
                        case 1: empDeptCodeLabel.setText("Department : Department 1");break;
                        case 2: empDeptCodeLabel.setText("Department : Department 2");break;
                        case 3: empDeptCodeLabel.setText("Department : Department 3");break;
                        case 4: empDeptCodeLabel.setText("Department : Department 4");break;
                        default:break;
                    }
                }
            }
        });
    }
}