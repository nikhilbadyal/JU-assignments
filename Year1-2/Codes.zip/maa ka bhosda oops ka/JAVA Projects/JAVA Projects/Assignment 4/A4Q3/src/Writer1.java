//import java.util.Random;
//
//public class Writer implements Runnable {
//    private Message message;
//
//    public Writer(Message message){
//        this.message = message;
//    }
//
//    public void run(){
//        String[] stringList = {
//          "Humpty Dumpty sat on a wall",
//          "Humpty Dumpty had a great fall",
//          "All the King's Horses and all the King's Men",
//          "Couldn't Put Humpty Together again."
//        };
//
//        Random random = new Random();
//
//        for(int i=0;i<stringList.length;i++){
//            message.write(stringList[i]);
//            try{
//                Thread.sleep(random.nextInt(200));
//            }catch(InterruptedException e){
//                System.out.println("Exception in Writer Thread");
//            }
//        }
//        message.write("Finished");
//    }
//}
