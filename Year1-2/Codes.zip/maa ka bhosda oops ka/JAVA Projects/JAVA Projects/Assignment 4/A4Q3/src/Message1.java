//public class Message {
//    private String message;
//    private boolean empty = true; //true when there is no message to read
//
//    public synchronized String read(){
//        while(empty){
//            try{
//                wait();
//            }catch (InterruptedException e){
//                System.out.println("Exception Read Method");
//            }
//        }
//        empty = true;
//        notifyAll();
//        return message;
//    }
//
//    public synchronized void write(String message){
//        while(!empty){
//            try{
//                wait();
//            }catch (InterruptedException e){
//                System.out.println("Exception Write method");
//            }
//        }
//        empty = false;
//        this.message = message;
//        notifyAll();
//    }
//}
