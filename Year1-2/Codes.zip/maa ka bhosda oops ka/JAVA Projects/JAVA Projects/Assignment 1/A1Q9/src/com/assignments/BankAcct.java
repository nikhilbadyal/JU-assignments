package com.assignments;
//Design a BankAcct class with account number, balance and interest rate as attribute.
//Interest rate is same for all account. Support must be there to initialize, change and display the interest rate.
//Also supports are to be there to return balance and calculate interest.
public class BankAcct {
    public long accountNumber;
    public double balance;
    static public double rate=6.5;

    void setAccountNumber(long accountNumber){
        this.accountNumber = accountNumber;
    }
    void setBalance(double balance){
        this.balance = balance;
    }

    long getAccountNumber(){
        return accountNumber;
    }
    double getBalance(){
        return balance;
    }

    static void changeRate(double newRate){
        rate = newRate;
    }
    static double getRate(){
        return rate;
    }

    double calculateInterest(double years){
        return (getBalance()*getRate()*years/100);
    }


}
