package com.assignments;
import java.util.Scanner;
//Design a BankAcct class with account number, balance and interest rate as attribute.//
// Interest rate is same for all account. Support must be there to initialize, change and display the interest rate.
//Also supports are to be there to return balance and calculate interest.
public class A1Q9 {

    public static void main(String[] args) {
	    BankAcct account = new BankAcct();
	    Scanner scan = new Scanner(System.in);
	    long accountNumber;
	    double balance;
	    double years;
	    double rate;
	    char choice = 'n';
        System.out.println("Current Interest Rate : " + account.getRate());
        System.out.println("Do you want to change the rate ? (y/n)");
        choice = scan.next().charAt(0);
        if(choice == 'y'){
            System.out.println("Enter new Rate : ");
            rate = scan.nextDouble();
            account.changeRate(rate);
        }
        System.out.println("Enter Account Number : ");
        accountNumber = scan.nextLong();
        System.out.println("Enter the Balance : ");
        balance = scan.nextDouble();
        System.out.println("Enter The time to calculate interest(Years)");
        years = scan.nextDouble();
        account.setAccountNumber(accountNumber);
        account.setBalance(balance);
        System.out.println("Interest for " + years + " year(s) is : " + account.calculateInterest(years));
    }
}
