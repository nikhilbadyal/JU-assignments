import java.util.Scanner;

public class A1Q5 {
    public static void main(String[] args){
        String string1,string2;
        Scanner scanner = new Scanner(System.in);

        //First Case
        System.out.print("Enter a String : ");
        string1 = scanner.next();
        string2 = string1;
        if(string1==string2)
            System.out.println("String1 == String2");
        if(string1.equals(string2))
            System.out.println("String1.equals(String2)");

        //Second Case
        System.out.print("Enter a String 1 : ");
        string1 = scanner.next();
        System.out.print("Enter a String 2 (Same as String 1) : ");
        string2 = scanner.next();
        if(string1==string2)
            System.out.println("String1 == String2");
        if(string1.equals(string2))
            System.out.println("String1.equals(String2)");
    }
}
