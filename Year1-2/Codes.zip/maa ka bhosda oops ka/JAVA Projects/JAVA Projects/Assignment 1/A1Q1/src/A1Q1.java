import java.util.InputMismatchException;
import java.util.Scanner;
public class A1Q1 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        short num1,num2;
        try{
            System.out.print("Enter first number (short) : ");
            num1 = scanner.nextShort();
            System.out.print("Enter second number (short) : ");
            num2 = scanner.nextShort();
            System.out.println("Sum of the two numbers : " + (num1+num2));
        }catch (InputMismatchException e){
            System.out.println("Invalid input given, make sure you give short numbers as input.");
        }
    }
}
