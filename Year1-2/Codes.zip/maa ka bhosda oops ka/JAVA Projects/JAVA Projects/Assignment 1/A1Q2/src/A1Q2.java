public class A1Q2 {
    public static void main(String[] args){
        System.out.println("Command-Line arguments are : ");
        //Loop through all arguments
        for(String str: args) {
            System.out.println(str);
        }
    }
}