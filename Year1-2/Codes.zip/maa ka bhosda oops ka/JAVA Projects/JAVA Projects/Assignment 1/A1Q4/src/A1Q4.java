import java.util.Scanner;
public class A1Q4 {
    public static void main(String[] args){
        final double pi = 3.14;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the radius : ");
        double radius = scanner.nextDouble();
        System.out.println("Area of the circle : " + (pi*radius*radius));
    }
}
