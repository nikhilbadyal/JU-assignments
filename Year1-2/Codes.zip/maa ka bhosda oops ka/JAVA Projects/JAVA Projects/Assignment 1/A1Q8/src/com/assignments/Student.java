package com.assignments;

public class Student {
    public short roll;
    public String name;
    public double score;

    Student(short roll){
        this(roll,null,0.0);
    }

    Student(short roll,String name){
        this(roll,name,0.0);
    }

    Student(){
        this((short) 0,null,0.0);
    }

    Student(short roll,String name,double score){
        this.roll = roll;
        this.name = name;
        this.score = score;
    }

    Student(Student s){
        this.roll = s.roll;
        this.name = s.name;
        this.score = s.score;
    }

    void showDetails(){
        System.out.println("Student's Name : "+name);
        System.out.println("Roll : " + roll + " Score : " + score);
    }

    boolean equals(Student s){
        if(this.roll == s.roll && this.score == s.score && this.name == s.name)
            return true;
        else
            return false;
    }
}

