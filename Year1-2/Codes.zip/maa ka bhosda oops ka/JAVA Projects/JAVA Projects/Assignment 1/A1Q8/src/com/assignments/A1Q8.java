package com.assignments;
//Add constructors in the Student class of earlier problem so that objects can be created with
//i) roll only, ii) roll and name only, iii) roll, name and score, iv) no value. Also include a copy constructor.
// Check whether constructors are working or not. Verify, copy constructor results into deep coy or not.
import java.util.Scanner;
public class A1Q8 {

    public static void main(String[] args) {
	    Scanner scan = new Scanner(System.in);
	    short roll;
	    String name;
	    double score;

        System.out.println("Enter Student Name : ");
        name = scan.nextLine();
        System.out.println("Enter Student Roll No. : ");
        roll = scan.nextShort();
        System.out.println("Enter Student Score : ");
        score = scan.nextDouble();

        System.out.println("\nInitialising Student 1 using Roll No. only");
        Student s1 = new Student(roll);
        s1.showDetails();
        System.out.println("\nInitialising Student 2 using Roll No. and Name");
        Student s2 = new Student(roll,name);
        s2.showDetails();
        System.out.println("\nInitialising Student 3 with no Value");
        Student s3 = new Student();
        s3.showDetails();
        System.out.println("\nInitialising Student 4 using Roll No.,Name and Score");
        Student s4 = new Student(roll,name,score);
        s4.showDetails();
        System.out.println("\nInitialising Student 5 using Student 4");
        Student s5 = new Student(s4);
        s5.showDetails();

        if(s4.equals(s5))
            System.out.println("\nCopy Constructor result into Deep Copy");
        else
            System.out.println("\nCopy Constructor doesn't result in Deep Copy");
    }
}
