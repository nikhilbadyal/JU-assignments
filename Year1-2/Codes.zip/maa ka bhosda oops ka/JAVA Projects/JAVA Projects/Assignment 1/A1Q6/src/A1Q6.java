public class A1Q6 {
    public static void main(String[] args){
        short shortVariable = 1;
        double doubleVariable = 1.00;
        System.out.println("Passing short as actual argument : ");
        show(shortVariable);

        System.out.println("\nPassing double as actual argument : ");
        show(doubleVariable);//Error when only show(int) is present
        //Error :incompatible types: possible lossy conversion from double to int
    }

    static void show(int a){
        System.out.println("show(int) called, Argument : " + a);
    }

    static void show(double a){
        System.out.println("show(double) called, Argument : " + a);
    }
}
