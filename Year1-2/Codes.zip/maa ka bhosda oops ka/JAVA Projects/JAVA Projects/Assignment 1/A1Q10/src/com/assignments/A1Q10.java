package com.assignments;
//Design a Metric class that supports Kilometre to Mile conversion with distance in Kilometre as argument
//and Mile to Kilometre conversion with distance in mile as argument
//Assume, one Mile equals 1.5 Kilometre.

import java.util.Scanner;
//Class A1Q10
public class A1Q10 {
    public static void main(String[] args) {    //main function
	    Scanner scan = new Scanner(System.in);
	    //Declaring Scanner Object to take User Input
	    double kilometer;
	    double mile;
	    byte choice;
	    Metric converter = new Metric();
	    //Creating a menu-driven program in an infinte loop (terminates on Input of 0)
	    while(true){
            System.out.println("1.Kilometer to Mile");
            System.out.println("2.Mile to Kilometer");
            System.out.println("0.Terminate");
            choice = scan.nextByte();
            if(choice == 1){
                System.out.println("Enter Kilometers : ");
                kilometer = scan.nextDouble();
                System.out.println(kilometer + " Km in Mile is : " + converter.kilometerToMile(kilometer));
            }
            else if(choice == 2){
                System.out.println("Enter Miles : ");
                mile = scan.nextDouble();
                System.out.println(mile + " mile(s) in Kilometer is : " + converter.mileToKilometer(mile));
            }
            else if(choice == 0){
                break;
            }
            //Invalid input handled in else section
            else{
                System.out.println("Invalid Input");
            }
        }
    }
}
