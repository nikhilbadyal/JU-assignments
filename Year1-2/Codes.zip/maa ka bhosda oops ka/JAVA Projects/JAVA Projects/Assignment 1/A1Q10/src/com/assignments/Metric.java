package com.assignments;    //all the declared class are enclosed inside com.assignments
//Design a Metric class that supports Kilometre to Mile conversion with distance in Kilometre as argument
//and Mile to Kilometre conversion with distance in mile as argument
//Assume, one Mile equals 1.5 Kilometre.
public class Metric {
    public static final double mileInKilometer = 1.5;
    public static final double kilometerInMile = 1/1.5;

    //Member function to convert mile to kilometer taking mile as argument
    public static double mileToKilometer(double mile){
        return mile*mileInKilometer;
    }

    //Member function to convert kilometer to mile taking kilometer as argument
    public static double kilometerToMile(double kilometer){
        return kilometer*kilometerInMile;
    }
}
