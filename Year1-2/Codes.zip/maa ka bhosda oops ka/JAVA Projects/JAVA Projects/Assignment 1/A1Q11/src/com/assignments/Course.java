package com.assignments;
//Each course has a course name, instructor and text book. One can set the course data and view the same.
//Design and implement the classes .
public class Course {
    public String name;
    public Instructor instructor;
    public Textbook textbook;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

    public Textbook getTextbook() {
        return textbook;
    }

    public void setTextbook(Textbook textbook) {
        this.textbook = textbook;
    }

    void show(){
        System.out.println("Course Name : "+getName());
        System.out.println("\nInstructor details : ");
        instructor.show();
        System.out.println("\nTextbook details : ");
        textbook.show();
    }
}
