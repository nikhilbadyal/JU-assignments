package com.assignments;
//Textbook has a title, author name and publisher. One can set the data for a textbook and view the same.
//Design and implement the classes .
public class Textbook {
    public String title;
    public String authorName;
    public String publisher;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    void show(){
        System.out.println("Title : " + getTitle());
        System.out.println("Author: " + getAuthorName());
        System.out.println("Publisher: " + getPublisher());
    }
}
