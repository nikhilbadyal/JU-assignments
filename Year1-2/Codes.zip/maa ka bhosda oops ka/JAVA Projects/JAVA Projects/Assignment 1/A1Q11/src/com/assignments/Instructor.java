package com.assignments;
//Each Instructor has name and phone number. One can view instructor information and set the information.
//Design and implement the classes.
public class Instructor {
    public String name;
    public long phoneNumber;

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    void show(){
        System.out.println("Name : " + getName());
        System.out.println("Phone No.: " + getPhoneNumber());
    }
}
