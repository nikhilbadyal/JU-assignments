package com.assignments;
import java.util.Scanner;
//Each Instructor has name and phone number. One can view instructor information and set the information.
//Textbook has a title, author name and publisher. One can set the data for a textbook and view the same.
//Each course has a course name, instructor and text book. One can set the course data and view the same.
//Design and implement the classes .
public class A1Q11 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Instructor instructor = new Instructor();
        Textbook textbook = new Textbook();
        Course course = new Course();

        String instructorName;
        long phoneNumber;
        String title,authorName,publisher;
        String courseName;

        System.out.println("Input Instructor Details : ");
        System.out.print("Name : ");
        instructorName = scan.nextLine();
        System.out.print("Phone Number : ");
        phoneNumber = scan.nextLong();
        instructor.setName(instructorName);
        instructor.setPhoneNumber(phoneNumber);

        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Input TextBook Details");
        System.out.print("Title : ");
        title = scanner2.nextLine();
        System.out.print("Author : ");
        authorName = scanner2.nextLine();
        System.out.print("Publisher : ");
        publisher = scanner2.nextLine();
        textbook.setTitle(title);
        textbook.setAuthorName(authorName);
        textbook.setPublisher(publisher);

        System.out.print("\nInput Course Name : ");
        courseName = scanner2.nextLine();
        course.setName(courseName);
        course.setInstructor(instructor);
        course.setTextbook(textbook);

        course.show();
    }
}
