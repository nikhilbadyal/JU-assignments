package com.assignments;

public class Student {
    public short roll;
    public String name;
    public double score;

    void setRoll(short roll){
        this.roll=roll;
    }
    void setName(String name){
        this.name=name;
    }
    void setScore(double score){
        this.score=score;
    }

    public short getRoll() {
        return roll;
    }

    public String getName() {
        return name;
    }

    public double getScore() {
        return score;
    }

    void showDetails(){
        System.out.println("Student's Name : " + getName());
        System.out.println("Roll : " + getRoll() + " Score : " + getScore());
    }
    void copy(Student s){
        s.setRoll(this.roll);
        s.setName(this.name);
        s.setScore(this.score);
    }
}
