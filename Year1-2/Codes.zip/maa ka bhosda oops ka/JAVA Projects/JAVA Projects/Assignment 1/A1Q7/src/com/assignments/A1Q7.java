package com.assignments;
//Design and implement Student class with roll, name and score as attributes.
//It will have methods to set attributes (attribute values passed as arguments), display the attributes,
//copy (that copies the content of invoking object to another object passed as argument).
//Verify that methods are working properly.
import  java.util.Scanner;
public class A1Q7 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Student s1 = new Student();
        Student s2 = new Student();
        String name;
        short roll;
        double score;

        System.out.println("Enter Student Name : ");
        name = scan.nextLine();
        s1.setName(name);

        System.out.println("Enter Roll No. : ");
        roll = scan.nextShort();
        s1.setRoll(roll);

        System.out.println("Enter Score : ");
        score = scan.nextDouble();
        s1.setScore(score);

        s1.copy(s2);
        System.out.println("Details of object 1 : ");
        s1.showDetails();
        System.out.println("Details of object 2 (copied from object 1 using copy method) : ");
        s2.showDetails();
    }
}
