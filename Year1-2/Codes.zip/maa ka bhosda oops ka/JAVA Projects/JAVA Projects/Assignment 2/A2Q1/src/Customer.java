import java.util.Scanner;

public class Customer {
    int customerId ;
    String name;
    double loanAmount;
    long phoneNumber;
    static double creditLimit = 0;

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void getDetails(){
        Scanner scanner = new Scanner(System.in);
        int customerId;
        String name;
        double loanAmount;
        long phoneNumber;
        System.out.println("Enter Customer Id : ");
        customerId = scanner.nextInt();scanner.nextLine();
        System.out.println("Enter Name : ");
        name = scanner.nextLine();
        System.out.println("Enter Phone Number : ");
        phoneNumber = scanner.nextLong();scanner.nextLine();
        this.setCustomerId(customerId);
        this.setName(name);
        this.setLoanAmount(0.0);
        this.setPhoneNumber(phoneNumber);
    }

    public double getCreditLimit() {
        return creditLimit;
    }

    public void showDetails(){
        System.out.println("Customer Id : " + this.getCustomerId());
        System.out.println("Name : " + this.getName());
        System.out.println("Phone Number : " + this.getPhoneNumber());
        System.out.println("Loan Amount : " + this.getLoanAmount());
    }
}
