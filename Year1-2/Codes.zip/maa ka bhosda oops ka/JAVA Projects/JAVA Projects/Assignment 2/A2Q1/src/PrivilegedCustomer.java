public class PrivilegedCustomer extends Customer {
    static double creditLimit = 4000000;

    @Override
    public double getCreditLimit(){
        return this.creditLimit;
    }

    @Override
    public void showDetails() {
        super.showDetails();
        System.out.println("Credit Limit : " + this.getCreditLimit());
    }
}
