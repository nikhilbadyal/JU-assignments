import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int choiceMain,choiceAccount;
        double loanAmount;
        boolean flag = false;
        Customer customer = new Customer();
        Scanner scanner = new Scanner(System.in);
        while(true) {
            System.out.println("1.Create Account");
            System.out.println("2.Show Details");
            System.out.println("3.Take Loan");
            System.out.println("0.Terminate");
            choiceMain = scanner.nextInt();scanner.nextLine();
            switch (choiceMain){
                case 1:{
                    System.out.println("1.Normal Account\n2.Privileged Account");
                    choiceAccount = scanner.nextInt();scanner.nextLine();
                    if(choiceAccount == 1){
                        flag = true;
                        customer = new NormalCustomer();
                        customer.getDetails();
                    }
                    else if(choiceAccount == 2){
                        flag = true;
                        customer = new PrivilegedCustomer();
                        customer.getDetails();
                    }
                    else{
                        System.out.println("Invalid Choice!!!");
                    }
                }
                break;
                case 2:{
                    if(flag) {
                        customer.showDetails();
                    }
                    else
                        System.out.println("Account not Created!!!");
                }
                break;
                case 3:{
                    if(flag) {
                        System.out.println("Enter Loan Amount : ");
                        loanAmount = scanner.nextDouble();scanner.nextLine();
                        if ((customer.getLoanAmount() + loanAmount) > customer.getCreditLimit())
                            System.out.println("Credit Limit Exceeded");
                        else{
                            System.out.println("New Loan Amount : " + (customer.getLoanAmount()+loanAmount));
                            customer.setLoanAmount(customer.getLoanAmount() + loanAmount);
                            System.out.println("Loan Sanctioned!!!");
                        }

                    }
                    else
                        System.out.println("Account not Created!!!");
                }
                break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid Input");
            }
        }
    }
}
