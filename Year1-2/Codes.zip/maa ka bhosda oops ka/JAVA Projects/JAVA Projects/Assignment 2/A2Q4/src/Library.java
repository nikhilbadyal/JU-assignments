import BookListPackage.BookList;
import MemberListPackage.MemberList;
import TransactionPackage.TransactionList;
import org.jetbrains.annotations.NotNull;

import java.util.Scanner;

public class Library implements LibraryInterface {
    public void addBook(@NotNull BookList bookList){
        bookList.addBook();
    }

    public void addMember(@NotNull MemberList memberList){
        memberList.addMember();
    }

    public void searchBook(@NotNull BookList bookList){
        bookList.displayBook();
    }

    public void searchMember(@NotNull MemberList memberList){
        memberList.displayMember();
    }

    public void totalBookListDisplay(@NotNull BookList bookList){
        bookList.totalListDisplay();
    }

    public void totalMemberListDisplay(@NotNull MemberList memberList){
        memberList.totalListDisplay();
    }

    public void issueBook(BookList bookList,MemberList memberList, @NotNull TransactionList transactionList){
        transactionList.issueBook(bookList,memberList);
    }

    public void returnBook(BookList bookList, MemberList memberList, @NotNull TransactionList transactionList){
        transactionList.returnBook(bookList,memberList);
    }


    void mainMenu(MemberList memberList, BookList bookList, TransactionList transactionList){
        Scanner scanner = new Scanner(System.in);
        int choice;
        while(true) {
            System.out.println("Library : ");
            System.out.println("1.Add New Book");
            System.out.println("2.Search Book");
            System.out.println("3.Show Book List");
            System.out.println("4.Add New Member");
            System.out.println("5.Search Member");
            System.out.println("6.Show Member List");
            System.out.println("7.Issue a Book");
            System.out.println("8.Return a Book");
            System.out.println("0.Exit");
            choice = scanner.nextInt();scanner.nextLine();
            switch(choice){
                case 1: addBook(bookList);break;
                case 2: searchBook(bookList);break;
                case 3: totalBookListDisplay(bookList);break;
                case 4: addMember(memberList);break;
                case 5: searchMember(memberList);break;
                case 6: totalMemberListDisplay(memberList);break;
                case 7: issueBook(bookList,memberList,transactionList);break;
                case 8: returnBook(bookList,memberList,transactionList);break;
                case 0: System.exit(0); break;
                default: System.out.println("Invalid Option!!!");
            }
        }
    }
}
