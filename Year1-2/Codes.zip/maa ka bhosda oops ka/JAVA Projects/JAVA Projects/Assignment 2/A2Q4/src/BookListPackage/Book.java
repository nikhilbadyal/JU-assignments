package BookListPackage;
class Book {
    int bookId;
    String title;
    int totalCopies;
    int numberOfCopiesAvailable;

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public void setTotalCopies(int totalCopies) {
        this.totalCopies = totalCopies;
    }

    public int getNumberOfCopiesAvailable() {
        return numberOfCopiesAvailable;
    }

    public void setNumberOfCopiesAvailable(int numberOfCopiesAvailable) {
        this.numberOfCopiesAvailable = numberOfCopiesAvailable;
    }

    boolean equals(Book book){
        return (this.getBookId() == book.getBookId());
    }

    void showBook(){
        System.out.println("Title : " + this.getTitle() + "\nBook Id : " + this.getBookId());
        System.out.println("Total Books : " + this.getTotalCopies() + "\nBooks Available : " + this.getNumberOfCopiesAvailable());
    }
}
