import BookListPackage.BookList;
import MemberListPackage.MemberList;
import TransactionPackage.TransactionList;

public class LibrarySystem {
    public static void main(String[] args){
        BookList bookList = new BookList();
        MemberList memberList = new MemberList();
        TransactionList transactionList = new TransactionList();
        Library library = new Library();
        library.mainMenu(memberList,bookList,transactionList);
    }
}
