package MemberListPackage;

import java.util.Scanner;

public class MemberList {
    Member[] member = new Member[20];
    static int size = 0;
    static final int limit = 4;

    public MemberList(){
        for(int i=0;i<20;i++)
            member[i] = new Member();
    }

    public boolean isUniqueMemberId(int memberId){
        for(int i=0;i<size;i++){
            if(member[i].getMemberId() == memberId)
                return false;
        }
        return true;
    }

    public int searchMember(int memberId){
        for(int i=0;i<size;i++){
            if(member[i].getMemberId() == memberId)
                return i;
        }
        return -1;
    }

    public void incrementIssue(int memberIndex){
        member[memberIndex].setNumberOfBookIssued(member[memberIndex].getNumberOfBookIssued()+1);
    }

    public void decrementIssue(int memberIndex){
        member[memberIndex].setNumberOfBookIssued(member[memberIndex].getNumberOfBookIssued()-1);
    }

    public boolean checkMemberValidity(int memberIndex){
        if(member[memberIndex].getNumberOfBookIssued() >= limit)
            return false;
        return true;
    }

    public void addMember(){
        int memberId,title,numberOfBookIssued;
        String name,dob;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Member Id (Integer) : ");
        memberId = scanner.nextInt();scanner.nextLine();
        if(isUniqueMemberId(memberId)){
            System.out.println("Enter Name : ");
            name = scanner.nextLine();
            System.out.println("Enter Date of Birth (dd/mm/yyyy) : ");
            dob = scanner.nextLine();
            numberOfBookIssued = 0;
            member[size].setName(name);
            member[size].setMemberId(memberId);
            member[size].setDob(dob);
            member[size].setNumberOfBookIssued(numberOfBookIssued);
            size++;
        }
        else
            System.out.println("Book Id Not Unique!!!");
    }

    public void displayMember(){
        Scanner scanner = new Scanner(System.in);
        int memberId,index;
        System.out.println("Enter Member Id : ");
        memberId = scanner.nextInt();scanner.nextLine();
        if((index=searchMember(memberId)) != -1){
            System.out.println("Member Details : ");
            member[index].showMember();
        }
        else
            System.out.println("Book Not Found.");
    }

    public void totalListDisplay(){
        if(size == 0){
            System.out.println("No Member Added!!!");
            return;
        }
        for(int i=0;i<size;i++)
            member[i].showMember();
    }
}
