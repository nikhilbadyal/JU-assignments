package BookListPackage;

import java.util.Scanner;

public class BookList {
    Book[] book = new Book[20];
    public static int size = 0;

    public BookList(){
        for(int i=0;i<20;i++){
            book[i] = new Book();
        }
    }

    public boolean isUniqueBookId(int bookId){
        for(int i=0;i<size;i++){
            if(book[i].getBookId() == bookId)
                return false;
        }
        return true;
    }

    public int searchBook(int bookId){
        for(int i=0;i<size;i++){
            if(book[i].getBookId() == bookId)
                return i;
        }
        return -1;
    }

    public void incrementCopiesAvailable(int bookIndex){
        book[bookIndex].setNumberOfCopiesAvailable(book[bookIndex].getNumberOfCopiesAvailable()+1);
    }

    public void decrementCopiesAvailable(int bookIndex){
        book[bookIndex].setNumberOfCopiesAvailable(book[bookIndex].getNumberOfCopiesAvailable()-1);
    }

    public boolean checkBookAvailability(int bookIndex){
        if(book[bookIndex].getNumberOfCopiesAvailable() > 0 )
            return true;
        return false;
    }

    public void addBook(){
        int bookId,totalCopies,numberOfCopiesAvailable;
        String title;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Book Id (Integer) : ");
        bookId = scanner.nextInt();scanner.nextLine();
        if(isUniqueBookId(bookId)){
            System.out.println("Enter Title : ");
            title = scanner.nextLine();
            System.out.println("Enter Total Copies Purchased : ");
            totalCopies = scanner.nextInt();scanner.nextLine();
            numberOfCopiesAvailable = totalCopies;
            book[size].setBookId(bookId);
            book[size].setTitle(title);
            book[size].setTotalCopies(totalCopies);
            book[size].setNumberOfCopiesAvailable(numberOfCopiesAvailable);
            size ++;
        }
        else
            System.out.println("Book Id Not Unique!!!");

    }

    public void changeTotalCopies(){
        Scanner scanner = new Scanner(System.in);
        int bookId,totalCopies,index;
        System.out.println("Enter Book Id to Edit : ");
        bookId = scanner.nextInt();scanner.nextLine();
        if((index=searchBook(bookId)) != -1){
            System.out.println("Book Found!!!\nEnter Total Book Purchased : ");
            totalCopies = scanner.nextInt();scanner.nextLine();
            if(book[index].getNumberOfCopiesAvailable()>totalCopies){
                System.out.println("Number of edited Books can't be less than books available in Library");
                return;
            }
            book[index].setTotalCopies(totalCopies);
        }
    }

    public void displayBook(){
        Scanner scanner = new Scanner(System.in);
        int bookId,index;
        System.out.println("Enter Book Id : ");
        bookId = scanner.nextInt();scanner.nextLine();
        if((index=searchBook(bookId)) != -1){
            System.out.println("Book Details : ");
            book[index].showBook();
        }
        else
            System.out.println("Book Not Found.");
    }

    public void totalListDisplay(){
        if(size == 0){
            System.out.println("No Books Added!!!");
            return;
        }
        System.out.println("Book List : ");
        for(int i=0;i<size;i++)
            book[i].showBook();
    }
}
