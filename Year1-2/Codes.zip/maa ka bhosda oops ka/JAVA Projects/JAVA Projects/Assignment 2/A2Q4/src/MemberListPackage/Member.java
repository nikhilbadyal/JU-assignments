package MemberListPackage;
class Member {
    int memberId;
    String name;
    String dob;
    int numberOfBookIssued;
    static int limit = 3;

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public int getNumberOfBookIssued() {
        return numberOfBookIssued;
    }

    public void setNumberOfBookIssued(int numberOfBookIssued) {
        this.numberOfBookIssued = numberOfBookIssued;
    }

    public static int getLimit() {
        return limit;
    }

    public static void setLimit(int limit) {
        Member.limit = limit;
    }

    void showMember(){
        System.out.println("Name : " + this.getName() + "\nMember Id : " + this.getMemberId());
        System.out.println("Total Books Issued : " + this.getNumberOfBookIssued());
    }
}
