import BookListPackage.BookList;
import MemberListPackage.MemberList;
import TransactionPackage.TransactionList;

public interface LibraryInterface{
    void addBook(BookList bookList);
    void searchBook(BookList bookList);
    void totalBookListDisplay(BookList bookList);
    void addMember(MemberList memberList);
    void searchMember(MemberList memberList);
    void totalMemberListDisplay(MemberList memberList);
    void issueBook(BookList bookList,MemberList memberList,TransactionList transactionList);
    void returnBook(BookList bookList,MemberList memberList,TransactionList transactionList);
}