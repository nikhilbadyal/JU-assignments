package TransactionPackage;
import BookListPackage.BookList;
import MemberListPackage.MemberList;
import org.jetbrains.annotations.NotNull;

import java.util.Scanner;

public class TransactionList {
    Transaction[] transaction = new Transaction[20];
    static int size = 0;
    static final int limit = 4;

    void addTransaction(int memberId, int bookId, boolean returnStatus){
        transaction[size].setMemberId(memberId);
        transaction[size].setBookId(bookId);
        transaction[size].setReturnStatus(returnStatus);
        size++;
    }

    void updateTransaction(int transactionIndex,boolean returnStatus){
        transaction[transactionIndex].setReturnStatus(returnStatus);
    }


    int searchTransaction(int memberId,int bookId){
        for(int i=0;i<size;i++){
            if(transaction[i].getMemberId() == memberId){
                if(transaction[i].getBookId() == bookId){
                    if(transaction[i].isReturnStatus() == true){
                        System.out.println("Transaction Found!!! Book Returned");
                        return -2;
                    }
                    else
                        return i;
                }
            }
        }
        return -1;
    }

    public void issueBook(@NotNull BookList bookList, @NotNull MemberList memberList){
        Scanner scanner = new Scanner(System.in);
        int memberId,bookId,memberIndex,bookIndex;
        System.out.println("Enter Member Id : ");
        memberId = scanner.nextInt();scanner.nextLine();
        if((memberIndex = memberList.searchMember(memberId)) == -1){
            System.out.println("Member doesn't exist!!");
            return;
        }
        else {
            if(!memberList.checkMemberValidity(memberIndex)){
                System.out.println("Maximum Books Issued!!!");
            }
            else{
                System.out.println("Enter Book Id : ");
                bookId = scanner.nextInt();scanner.nextLine();
                if((bookIndex = bookList.searchBook(bookId)) == -1){
                    System.out.println("Book doesn't exist!!!");
                }
                else{
                    if(!bookList.checkBookAvailability(bookIndex)){
                        System.out.println("Book is Out of Stock!!!");
                    }
                    else{
                        addTransaction(memberId,bookId,false);
                        memberList.incrementIssue(memberIndex);
                        bookList.decrementCopiesAvailable(bookIndex);
                        System.out.println("Book Issued!!!");
                    }
                }
            }
        }
    }

    public void returnBook(@NotNull BookList bookList, @NotNull MemberList memberList){
        Scanner scanner = new Scanner(System.in);
        int transactionIndex,memberIndex,bookIndex,memberId,bookId;
        System.out.println("Enter Member Id : ");
        memberId = scanner.nextInt();scanner.nextLine();
        if((memberIndex = memberList.searchMember(memberId)) == -1){
            System.out.println("Member doesn't exist!!");
            return;
        }
        else{
            System.out.println("Enter Book Id : ");
            bookId = scanner.nextInt();scanner.nextLine();
            transactionIndex = searchTransaction(memberId,bookId);
            if(transactionIndex == -1){
                System.out.println("Transaction Not Found!!!");
            }
            else if(transactionIndex == -2)
                return;
            else{
                updateTransaction(transactionIndex,true);
                memberIndex = memberList.searchMember(transaction[transactionIndex].getMemberId());
                bookIndex = bookList.searchBook(transaction[transactionIndex].getBookId());
                memberList.decrementIssue(memberIndex);
                bookList.incrementCopiesAvailable(bookIndex);
                System.out.println("Book Returned!!!");
            }
        }
    }
}
