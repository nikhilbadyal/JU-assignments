import java.util.Scanner;

public class A2Q2 {
    public static void main(String[] args){
        int choice;
        String name;
        Address address = new Address();
        Student student = new Student();
        Faculty faculty = new Faculty();
        String premisesNumber,street,city,state,emailId,course,department,specialisation;
        long pin,phoneNumber;
        int rollNumber,employId;
        Scanner scan = new Scanner(System.in);
        boolean flagStudent = false;
        boolean flagFaculty = false;
        while(true){
            System.out.println("1.Create Student\n2.Create Faculty\n3.View Student\n4.View Faculty\n5.Edit Student");
            System.out.println("6.Edit Faculty\n0.Terminate");
            choice = scan.nextInt();
            switch(choice){
                case 1:{
                    flagStudent = true;
                    scan.nextLine();
                    System.out.println("Enter Name :");name = scan.nextLine();
                    System.out.println("Enter Roll No. : ");rollNumber = scan.nextInt();scan.nextLine();
                    System.out.println("Enter Email Id : ");emailId = scan.nextLine();
                    System.out.println("Enter Course : ");course = scan.nextLine();
                    System.out.println("Enter Address : \nPremises");premisesNumber = scan.nextLine();
                    System.out.println("Street : ");street = scan.nextLine();
                    System.out.println("City : ");city = scan.nextLine();
                    System.out.println("PinCode : ");pin = scan.nextLong();scan.nextLine();
                    System.out.println("State : ");state = scan.nextLine();
                    System.out.println("Enter Phone No. : ");phoneNumber = scan.nextLong();scan.nextLine();
                    address.setPremisesNumber(premisesNumber);
                    address.setCity(city);address.setPin(pin);address.setState(state);address.setStreet(street);
                    student.setName(name);student.setCourse(course);student.setRollNumber(rollNumber);
                    student.setAddress(address);student.setEmailId(emailId);student.setPhoneNumber(phoneNumber);
                }
                break;

                case 2:{
                    flagFaculty = true;
                    scan.nextLine();
                    System.out.println("Enter Name :");name = scan.nextLine();
                    System.out.println("Enter Employ Id : ");employId = scan.nextInt();scan.nextLine();
                    System.out.println("Enter Email Id : ");emailId = scan.nextLine();
                    System.out.println("Enter Department : ");department = scan.nextLine();
                    System.out.println("Enter Specialisation");specialisation = scan.nextLine();
                    System.out.println("Enter Address : \nPremises");premisesNumber = scan.nextLine();
                    System.out.println("Street : ");street = scan.nextLine();
                    System.out.println("City : ");city = scan.nextLine();
                    System.out.println("PinCode : ");pin = scan.nextLong();scan.nextLine();
                    System.out.println("State : ");state = scan.nextLine();
                    System.out.println("Enter Phone No. : ");phoneNumber = scan.nextLong();scan.nextLine();
                    address.setPremisesNumber(premisesNumber);address.setCity(city);
                    address.setPin(pin);address.setState(state);address.setStreet(street);
                    faculty.setName(name);faculty.setEmployId(employId);faculty.setDepartment(department);
                    faculty.setSpecialisation(specialisation);faculty.setPhoneNumber(phoneNumber);
                    faculty.setEmailId(emailId);faculty.setAddress(address);
                }
                break;

                case 3:{
                    if(flagStudent == false){
                        System.out.println("Student not Created");
                        break;
                    }
                    else{
                        student.showDetails();
                    }
                }
                break;

                case 4:{
                    if(flagFaculty == false){
                        System.out.println("Faculty not Created");
                        break;
                    }
                    else{
                        faculty.showDetails();
                    }
                }
                break;

                case 5:{
                    if(flagStudent == false){
                        System.out.println("Student not Created");
                        break;
                    }
                    else{
                        int flag = 1;
                        while(flag == 1){
                            System.out.println("1.Name\n2.PhoneNumber\n3.EmailId\n4.Roll Number\n5.Course\n6.Address");
                            System.out.println("\n0.Done");
                            choice = scan.nextInt();scan.nextLine();
                            switch (choice){
                                case 1:{
                                    System.out.println("Enter Name :");name = scan.nextLine();
                                    student.setName(name);
                                }
                                break;

                                case 2:{
                                    System.out.println("Enter Phone No. : ");phoneNumber = scan.nextLong();
                                    scan.nextLine();
                                    student.setPhoneNumber(phoneNumber);
                                }
                                break;

                                case 3:{
                                    System.out.println("Enter Email Id : ");emailId = scan.nextLine();
                                    student.setEmailId(emailId);
                                }
                                break;

                                case 4:{
                                    System.out.println("Enter Roll No. : ");rollNumber = scan.nextInt();scan.nextLine();
                                    student.setRollNumber(rollNumber);
                                }
                                break;

                                case 5:{
                                    System.out.println("Enter Course : ");course = scan.nextLine();
                                    student.setCourse(course);
                                }
                                break;

                                case 6:{
                                    address = student.getAddress();
                                    int flag1 = 1;
                                    while (flag1 == 1) {
                                        System.out.println("1.Premises No.\n2.Street\n3.City\n4.Pin\n5.State\n0.Done");
                                        choice = scan.nextInt();scan.nextLine();
                                        switch (choice){
                                            case 1:{
                                                System.out.println("Premises: ");premisesNumber = scan.nextLine();
                                                address.setPremisesNumber(premisesNumber);
                                            }
                                            break;

                                            case 2:{
                                                System.out.println("Street : ");street = scan.nextLine();
                                                address.setStreet(street);
                                            }
                                            break;

                                            case 3:{
                                                System.out.println("City : ");city = scan.nextLine();
                                                address.setCity(city);
                                            }
                                            break;

                                            case 4:{
                                                System.out.println("PinCode : ");pin = scan.nextLong();scan.nextLine();
                                                address.setPin(pin);
                                            }
                                            break;

                                            case 5:{
                                                System.out.println("State : ");state = scan.nextLine();
                                                address.setState(state);
                                            }
                                            break;

                                            case 0:{
                                                flag1 = 0;
                                            }
                                            break;

                                            default:{
                                                System.out.println("Invalid Input");
                                            }
                                        }
                                    }
                                    student.setAddress(address);
                                }
                                break;

                                case 0:{
                                    flag = 0;
                                }
                                break;

                                default:{
                                    System.out.println("Invalid Input");
                                }
                            }
                        }
                    }
                }
                break;

                case 6:{
                    if(flagFaculty == false){
                        System.out.println("Faculty not Created");
                        break;
                    }
                    else{
                        int flag = 1;
                        while(flag == 1){
                            System.out.println("1.Name\n2.PhoneNumber\n3.EmailId\n4.Employ Id\n5.Department\n6.Address");
                            System.out.println("\n7.Specialisation\n0.Done");
                            choice = scan.nextInt();scan.nextLine();
                            switch (choice){
                                case 1:{
                                    System.out.println("Enter Name :");name = scan.nextLine();
                                    faculty.setName(name);
                                }
                                break;

                                case 2:{
                                    System.out.println("Enter Phone No. : ");phoneNumber = scan.nextLong();
                                    scan.nextLine();
                                    faculty.setPhoneNumber(phoneNumber);
                                }
                                break;

                                case 3:{
                                    System.out.println("Enter Email Id : ");emailId = scan.nextLine();
                                    faculty.setEmailId(emailId);
                                }
                                break;

                                case 4:{
                                    System.out.println("Enter Employ Id : ");employId = scan.nextInt();scan.nextLine();
                                    faculty.setEmployId(employId);
                                }
                                break;

                                case 5:{
                                    System.out.println("Enter Department : ");department = scan.nextLine();
                                    faculty.setDepartment(department);
                                }
                                break;

                                case 6:{
                                    address = faculty.getAddress();
                                    int flag1 = 1;
                                    while (flag1 == 1) {
                                        System.out.println("1.Premises No.\n2.Street\n3.City\n4.Pin\n5.State\n0.Done");
                                        choice = scan.nextInt();scan.nextLine();
                                        switch (choice){
                                            case 1:{
                                                System.out.println("Premises: ");premisesNumber = scan.nextLine();
                                                address.setPremisesNumber(premisesNumber);
                                            }
                                            break;

                                            case 2:{
                                                System.out.println("Street : ");street = scan.nextLine();
                                                address.setStreet(street);
                                            }
                                            break;

                                            case 3:{
                                                System.out.println("City : ");city = scan.nextLine();
                                                address.setCity(city);
                                            }
                                            break;

                                            case 4:{
                                                System.out.println("PinCode : ");pin = scan.nextLong();scan.nextLine();
                                                address.setPin(pin);
                                            }
                                            break;

                                            case 5:{
                                                System.out.println("State : ");state = scan.nextLine();
                                                address.setState(state);
                                            }
                                            break;

                                            case 0:{
                                                flag1 = 0;
                                            }
                                            break;

                                            default:{
                                                System.out.println("Invalid Input");
                                            }
                                        }
                                    }
                                    faculty.setAddress(address);
                                }

                                case 7:{
                                    System.out.println("Enter Specialisation");specialisation = scan.nextLine();
                                    faculty.setSpecialisation(specialisation);
                                }
                                break;

                                case 0:{
                                    flag = 0;
                                }
                                break;

                                default:{
                                    System.out.println("Invalid Input");
                                }
                            }
                        }
                    }
                }
                break;

                case 0:
                    System.exit(0);

                default:
                    System.out.println("Invalid Input");
            }
        }
    }
}

class Address{
    String premisesNumber;
    String street;
    String city;
    long pin;
    String state;
    Address (){
        pin = 0;
        premisesNumber = null;
        state = null;
        street = null;
        city = null;
    }
    public String getPremisesNumber() {
        return premisesNumber;
    }

    public void setPremisesNumber(String premisesNumber) {
        this.premisesNumber = premisesNumber;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public long getPin() {
        return pin;
    }

    public void setPin(long pin) {
        this.pin = pin;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void showDetails(){
        System.out.println("Premises No. " + this.getPremisesNumber() + "\nStreet : " + this.getStreet());
        System.out.println("City : " + this.getCity() + "PinCode : " + this.getPin());
        System.out.println("State : " + this.getState());
    }

}
class Person{
    String name;
    Address address;
    long phoneNumber;
    String emailId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
}
class Student extends Person{
    int rollNumber;
    String course;

    public int getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public void showDetails(){
        System.out.println("Name : " + this.getName());
        System.out.println("Roll : " + this.getRollNumber() + "Course : " + this.getCourse());
        System.out.println("Email Id : " + this.getEmailId());
        System.out.println("Phone No. : " + this.getPhoneNumber() + "\nAddress : ");
        this.getAddress().showDetails();
    }
}
class Faculty extends Person{
    int employId;
    String department;
    String specialisation;

    public int getEmployId() {
        return employId;
    }

    public void setEmployId(int employId) {
        this.employId = employId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSpecialisation() {
        return specialisation;
    }

    public void setSpecialisation(String specialisation) {
        this.specialisation = specialisation;
    }
    public void showDetails(){
        System.out.println("Name : " + this.getName());
        System.out.println("Employ Id : " + this.getEmployId() + "Department : " + this.getDepartment());
        System.out.println("Specialisation : " + this.getSpecialisation());
        System.out.println("Email Id : " + this.getEmailId());
        System.out.println("Phone No. : " + this.getPhoneNumber() + "\nAddress : ");
        this.getAddress().showDetails();
    }
}