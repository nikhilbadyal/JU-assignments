import BookListPackage.BookList;
import MemberListPackage.MemberList;
import TransactionPackage.TransactionList;

import java.util.Scanner;

public class Library {
    public static void main(String[] args){
        MemberList memberList = new MemberList();
        BookList bookList = new BookList();
        TransactionList transactionList = new TransactionList();
        mainMenu(memberList,bookList,transactionList);
    }

    static void mainMenu(MemberList memberList,BookList bookList,TransactionList transactionList){
        Scanner scanner = new Scanner(System.in);
        int choice;
        while(true) {
            System.out.println("Library : ");
            System.out.println("1.Add New Book");
            System.out.println("2.Add Copies of a Existing Book");
            System.out.println("3.Show Book List");
            System.out.println("4.Show Book");
            System.out.println("5.Add New Member");
            System.out.println("6.Show Member List");
            System.out.println("7.Show Member");
            System.out.println("8.Issue a Book");
            System.out.println("9.Return a Book");
            System.out.println("0.Exit");
            choice = scanner.nextInt();scanner.nextLine();
            switch(choice){
                case 1: bookList.addBook(); break;
                case 2: bookList.changeTotalCopies(); break;
                case 3: bookList.totalListDisplay(); break;
                case 4: bookList.displayBook(); break;
                case 5: memberList.addMember(); break;
                case 6: memberList.totalListDisplay(); break;
                case 7: memberList.displayMember(); break;
                case 8: transactionList.issueBook(bookList,memberList);
                case 9: transactionList.returnBook(bookList,memberList);
                case 0: System.exit(0); break;
                default: System.out.println("Invalid Option!!!");
            }
        }
    }
}

