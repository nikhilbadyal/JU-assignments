import java.util.Scanner;

public class A2Q6 {
    public static void main(String[] args) {
        Byte choice;
        int basicType;
        Integer objectType;
        String numericString;
        Scanner s = new Scanner(System.in);
        System.out.println("Basic type : int , Wrapper Class : Interger");
        while (true) {
            System.out.println("Choose Following conersions : ");
            System.out.println("1.Basic to Object");
            System.out.println("2.Object to Basic");
            System.out.println("3.Basic to String");
            System.out.println("4.String to Object");
            System.out.println("5.Object to String");
            System.out.println("0.Terminate");
            choice = s.nextByte();
            switch (choice){
                case 1 : {
                    System.out.println("Enter a integer value :");
                    basicType = s.nextInt();
                    objectType = basicType;
                    System.out.println("Coversion Successful, Value: " + objectType);
                }
                break;

                case 2: {
                    System.out.println("Enter a integer value :");
                    objectType = s.nextInt();
                    basicType = objectType;
                    System.out.println("Coversion Successful, Value: " + basicType);
                }
                break;

                case 3: {
                    System.out.println("Enter a integer value :");
                    basicType = s.nextInt();
                    numericString = Integer.toString(basicType);
                    System.out.println("Coversion Successful, Value: " + numericString);
                }
                break;

                case 4: {
                    System.out.println("Enter a Numeric String :");
                    boolean numeric = true;
                    s.nextLine();
                    numericString = s.nextLine();
                    objectType = 0;
                    try {
                        objectType = Integer.parseInt(numericString);
                    } catch (NumberFormatException e) {
                        numeric = false;
                    }
                    if(!numeric){
                        System.out.println("Given String is not numeric");
                    }
                    else{
                        System.out.println("Conversion Successful, Value: " + objectType);
                    }
                }
                break;

                case 5: {
                    System.out.println("Enter a integer value :");
                    objectType = s.nextInt();
                    numericString = Integer.toString(objectType);
                    System.out.println("Coversion Successful, Value: " + numericString);
                }
                break;

                case 0:
                    System.exit(0);

                default: {
                    System.out.println("Invalid input");
                }

            }
        }
    }
}
