import java.util.Scanner;

public class A2Q7 {
    public static void main (String []args) {
        Scanner s = new Scanner(System.in);
        String string;
        int i;
        int fromIndex = 0;
        int numberOfA = 0;
        int countNumberOfAnd = 0;
        boolean theAtFirst = false;
        System.out.println("Enter a String :");
        string = s.nextLine();

        for(i=0; i<string.length() ;i++)
            if(string.charAt(i) == 'a')
                numberOfA++;
        while((fromIndex = string.indexOf("and",fromIndex)) != -1){
            countNumberOfAnd++;
            fromIndex++;
        }
        if(string.indexOf("The",0)==0)
            theAtFirst = true;
        char[] ch = new char[string.length()];
        for(i=0;i<string.length();i++)
            ch[i] = string.charAt(i);
        String[] tokens = string.split("[@.]");
        System.out.println("Number of 'a' in the string : " + numberOfA);
        System.out.println("Number of 'and' in the string : " + countNumberOfAnd);
        if(theAtFirst)
            System.out.println("String starts with 'The'");
        else
            System.out.println("String doesn't start with 'The'");
        System.out.println("String as Character array");
        for(i=0;i<string.length();i++)
            System.out.print(ch[i]);
        System.out.println("\nTokens : ");
        for(String a : tokens)
            System.out.println(a);
    }
}
