import java.util.Scanner;

public class A2Q5 {
    public static void main(String[] args){
        String name;
        int roll;
        double score;
        Scanner s = new Scanner(System.in);
        Student student = new Student();
        System.out.println("Enter Name : ");
        name = s.nextLine();
        student.setName(name);
        System.out.println("Enter Roll : ");
        roll = s.nextInt();
        student.setRoll(roll);
        s.nextLine();
        System.out.println("Enter Score [0,100] : ");
        score = s.nextDouble();
        student.setScore(score);
        System.out.println("Student Details : ");
        System.out.println("Name : " + student.getName() + "Roll : " + student.getRoll());
        System.out.println("Score : " + student.getScore());
    }
}

class Student{
    int roll;
    String name;
    double score;

    public int getRoll() {
        return roll;
    }

    public void setRoll(int roll) {
        this.roll = roll;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        if(score<0 || score>100){
            System.out.println("Invalid Score, Score reset to 0.0");
            this.score = 0.0;
        }
        else
            this.score = score;
    }
}
